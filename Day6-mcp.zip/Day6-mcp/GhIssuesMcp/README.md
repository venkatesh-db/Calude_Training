# GhIssuesMcp

A minimal MCP server (stdio transport) that exposes real GitHub Issues as
MCP tools, with a permission gate on mutating calls and a hooks pipeline
that logs every call. See [../PROMPT.md](../PROMPT.md) for the ticket this
was built from.

## Requirements

- .NET 8 SDK
- A GitHub personal access token with `repo` scope (or `public_repo` for
  public repos only)

## Setup

```bash
export GITHUB_TOKEN=ghp_xxxxxxxxxxxx
```

Edit `appsettings.json` to list the repos mutating tools are allowed to
touch:

```json
{
  "GitHub": {
    "WritableRepos": ["your-org/your-sandbox-repo"]
  }
}
```

## Build & run

```bash
dotnet build
dotnet run
```

The server speaks MCP over stdio — point an MCP client (Claude Desktop,
Claude Code, etc.) at it, e.g. in `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "gh-issues": {
      "command": "dotnet",
      "args": ["run", "--project", "/absolute/path/to/GhIssuesMcp"],
      "env": { "GITHUB_TOKEN": "ghp_xxxxxxxxxxxx" }
    }
  }
}
```

## Tools

| Tool | Mutating? | Notes |
|---|---|---|
| `list_issues(owner, repo, state?)` | No | first 30 issues |
| `get_issue(owner, repo, number)` | No | |
| `add_comment(owner, repo, number, body)` | Yes | blocked unless repo is in `WritableRepos` |
| `close_issue(owner, repo, number)` | Yes | blocked unless repo is in `WritableRepos` |

## How hooks & permissions work

- `ToolCallHooks.RunAsync` wraps every tool call: it logs a pre-call line,
  runs an optional permission check for mutating calls, runs the actual
  work, then logs a post-call line with elapsed time and success/failure —
  win or lose, to stderr (stdout is reserved for the MCP protocol).
- `PermissionGate.EnsureWritable` throws before any HTTP call is made if
  `owner/repo` isn't in the `GitHub:WritableRepos` allow-list in
  `appsettings.json`. Read tools never call it.

## Try it

```bash
export GITHUB_TOKEN=ghp_xxxxxxxxxxxx
dotnet build
# then wire into an MCP client and call, e.g.:
#   list_issues(owner="octocat", repo="Hello-World")
#   add_comment(owner="octocat", repo="Hello-World", number=1, body="hi")
#     -> permission-denied error, since octocat/Hello-World isn't allow-listed
```
