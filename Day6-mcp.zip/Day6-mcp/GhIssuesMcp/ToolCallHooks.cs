using System.Diagnostics;
using Microsoft.Extensions.Logging;

namespace GhIssuesMcp;

/// <summary>
/// Every tool routes its work through <see cref="RunAsync"/> instead of doing
/// HTTP/permission work inline, so logging and permission checks live in one
/// place instead of being copy-pasted per tool.
/// </summary>
public sealed class ToolCallHooks(ILogger<ToolCallHooks> logger)
{
    public async Task<T> RunAsync<T>(
        string toolName,
        bool isMutating,
        Action? permissionCheck,
        Func<Task<T>> work)
    {
        var sw = Stopwatch.StartNew();
        logger.LogInformation("[pre-call] tool={Tool} mutating={Mutating}", toolName, isMutating);

        try
        {
            if (isMutating)
            {
                permissionCheck?.Invoke();
            }

            var result = await work();

            logger.LogInformation(
                "[post-call] tool={Tool} status=ok elapsedMs={Elapsed}",
                toolName, sw.ElapsedMilliseconds);

            return result;
        }
        catch (Exception ex)
        {
            logger.LogWarning(
                "[post-call] tool={Tool} status=error elapsedMs={Elapsed} error={Error}",
                toolName, sw.ElapsedMilliseconds, ex.Message);
            throw;
        }
    }
}
