using Microsoft.Extensions.Configuration;

namespace GhIssuesMcp;

/// <summary>
/// Config-driven allow-list for mutating operations. A repo not listed here
/// can never be written to, regardless of what a tool call asks for.
/// </summary>
public sealed class PermissionGate
{
    private readonly HashSet<string> _writableRepos;

    public PermissionGate(IConfiguration config)
    {
        _writableRepos = config.GetSection("GitHub:WritableRepos").Get<string[]>()?.ToHashSet(StringComparer.OrdinalIgnoreCase)
            ?? new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    }

    public void EnsureWritable(string owner, string repo)
    {
        var key = $"{owner}/{repo}";
        if (!_writableRepos.Contains(key))
        {
            throw new PermissionDeniedException(
                $"'{key}' is not in the writable-repo allow-list. " +
                "Add it to appsettings.json under GitHub:WritableRepos to permit mutating calls.");
        }
    }
}

public sealed class PermissionDeniedException(string message) : Exception(message);
