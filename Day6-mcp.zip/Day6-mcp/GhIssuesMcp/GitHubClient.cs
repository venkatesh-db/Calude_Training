using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Configuration;

namespace GhIssuesMcp;

public sealed class GitHubClient
{
    private readonly HttpClient _http;

    public GitHubClient(HttpClient http, IConfiguration config)
    {
        var token = Environment.GetEnvironmentVariable("GITHUB_TOKEN")
            ?? throw new InvalidOperationException("GITHUB_TOKEN environment variable is not set.");

        http.BaseAddress = new Uri("https://api.github.com/");
        http.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("GhIssuesMcp", "1.0"));
        http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vnd.github+json"));
        http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        _http = http;
    }

    public async Task<List<Issue>> ListIssuesAsync(string owner, string repo, string state = "open")
    {
        var issues = await _http.GetFromJsonAsync<List<Issue>>(
            $"repos/{owner}/{repo}/issues?state={state}&per_page=30");
        return issues ?? [];
    }

    public async Task<Issue?> GetIssueAsync(string owner, string repo, int number)
        => await _http.GetFromJsonAsync<Issue>($"repos/{owner}/{repo}/issues/{number}");

    public async Task<Comment> AddCommentAsync(string owner, string repo, int number, string body)
    {
        var response = await _http.PostAsJsonAsync(
            $"repos/{owner}/{repo}/issues/{number}/comments",
            new { body });
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<Comment>())!;
    }

    public async Task<Issue> CloseIssueAsync(string owner, string repo, int number)
    {
        var response = await _http.PatchAsJsonAsync(
            $"repos/{owner}/{repo}/issues/{number}",
            new { state = "closed" });
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<Issue>())!;
    }
}

public sealed class Issue
{
    [JsonPropertyName("number")] public int Number { get; set; }
    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("state")] public string State { get; set; } = "";
    [JsonPropertyName("html_url")] public string HtmlUrl { get; set; } = "";
    [JsonPropertyName("body")] public string? Body { get; set; }
}

public sealed class Comment
{
    [JsonPropertyName("id")] public long Id { get; set; }
    [JsonPropertyName("html_url")] public string HtmlUrl { get; set; } = "";
}
