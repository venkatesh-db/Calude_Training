using System.ComponentModel;
using ModelContextProtocol.Server;

namespace GhIssuesMcp;

[McpServerToolType]
public sealed class IssueTools(GitHubClient github, PermissionGate permissions, ToolCallHooks hooks)
{
    [McpServerTool(Name = "list_issues"), Description("Lists issues for a GitHub repo. Read-only.")]
    public Task<List<Issue>> ListIssues(
        [Description("Repo owner, e.g. 'octocat'")] string owner,
        [Description("Repo name, e.g. 'Hello-World'")] string repo,
        [Description("open, closed, or all")] string state = "open")
        => hooks.RunAsync(nameof(ListIssues), isMutating: false, permissionCheck: null,
            work: () => github.ListIssuesAsync(owner, repo, state));

    [McpServerTool(Name = "get_issue"), Description("Fetches a single GitHub issue by number. Read-only.")]
    public Task<Issue?> GetIssue(
        [Description("Repo owner")] string owner,
        [Description("Repo name")] string repo,
        [Description("Issue number")] int number)
        => hooks.RunAsync(nameof(GetIssue), isMutating: false, permissionCheck: null,
            work: () => github.GetIssueAsync(owner, repo, number));

    [McpServerTool(Name = "add_comment"), Description("Adds a comment to a GitHub issue. Mutating — only allowed on allow-listed repos.")]
    public Task<Comment> AddComment(
        [Description("Repo owner")] string owner,
        [Description("Repo name")] string repo,
        [Description("Issue number")] int number,
        [Description("Comment body")] string body)
        => hooks.RunAsync(nameof(AddComment), isMutating: true,
            permissionCheck: () => permissions.EnsureWritable(owner, repo),
            work: () => github.AddCommentAsync(owner, repo, number, body));

    [McpServerTool(Name = "close_issue"), Description("Closes a GitHub issue. Mutating — only allowed on allow-listed repos.")]
    public Task<Issue> CloseIssue(
        [Description("Repo owner")] string owner,
        [Description("Repo name")] string repo,
        [Description("Issue number")] int number)
        => hooks.RunAsync(nameof(CloseIssue), isMutating: true,
            permissionCheck: () => permissions.EnsureWritable(owner, repo),
            work: () => github.CloseIssueAsync(owner, repo, number));
}
