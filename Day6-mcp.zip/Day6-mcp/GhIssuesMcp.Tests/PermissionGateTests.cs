using GhIssuesMcp;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace GhIssuesMcp.Tests;

public class PermissionGateTests
{
    private static PermissionGate BuildGate(params string[] writableRepos)
    {
        var config = new ConfigurationBuilder()
            .AddInMemoryCollection(
                writableRepos.Select((r, i) => new KeyValuePair<string, string?>($"GitHub:WritableRepos:{i}", r)))
            .Build();
        return new PermissionGate(config);
    }

    [Fact]
    public void EnsureWritable_AllowsRepoOnAllowList()
    {
        var gate = BuildGate("venkatesh-db/sandbox");
        var ex = Record.Exception(() => gate.EnsureWritable("venkatesh-db", "sandbox"));
        Assert.Null(ex);
    }

    [Fact]
    public void EnsureWritable_IsCaseInsensitive()
    {
        var gate = BuildGate("venkatesh-db/sandbox");
        var ex = Record.Exception(() => gate.EnsureWritable("Venkatesh-DB", "SANDBOX"));
        Assert.Null(ex);
    }

    [Fact]
    public void EnsureWritable_BlocksRepoNotOnAllowList()
    {
        var gate = BuildGate("venkatesh-db/sandbox");
        Assert.Throws<PermissionDeniedException>(() => gate.EnsureWritable("octocat", "Hello-World"));
    }

    [Fact]
    public void EnsureWritable_BlocksEverything_WhenAllowListIsEmpty()
    {
        var gate = BuildGate();
        Assert.Throws<PermissionDeniedException>(() => gate.EnsureWritable("anyone", "anyrepo"));
    }
}
