using GhIssuesMcp;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

namespace GhIssuesMcp.Tests;

public class ToolCallHooksTests
{
    private static ToolCallHooks BuildHooks() => new(NullLogger<ToolCallHooks>.Instance);

    [Fact]
    public async Task RunAsync_ReturnsWorkResult_WhenNotMutating()
    {
        var hooks = BuildHooks();
        var result = await hooks.RunAsync("test_tool", isMutating: false, permissionCheck: null,
            work: () => Task.FromResult(42));
        Assert.Equal(42, result);
    }

    [Fact]
    public async Task RunAsync_RunsPermissionCheck_BeforeWork_WhenMutating()
    {
        var hooks = BuildHooks();
        var workRan = false;

        var ex = await Assert.ThrowsAsync<PermissionDeniedException>(() =>
            hooks.RunAsync<string>("mutate_tool", isMutating: true,
                permissionCheck: () => throw new PermissionDeniedException("denied"),
                work: () => { workRan = true; return Task.FromResult("done"); }));

        Assert.False(workRan, "work must not run when the permission check fails");
        Assert.Equal("denied", ex.Message);
    }

    [Fact]
    public async Task RunAsync_SkipsPermissionCheck_WhenNotMutating()
    {
        var hooks = BuildHooks();
        var checkRan = false;

        var result = await hooks.RunAsync("read_tool", isMutating: false,
            permissionCheck: () => checkRan = true,
            work: () => Task.FromResult("ok"));

        Assert.False(checkRan);
        Assert.Equal("ok", result);
    }

    [Fact]
    public async Task RunAsync_AllowsWork_WhenPermissionCheckPasses()
    {
        var hooks = BuildHooks();
        var result = await hooks.RunAsync("mutate_tool", isMutating: true,
            permissionCheck: () => { },
            work: () => Task.FromResult("mutated"));

        Assert.Equal("mutated", result);
    }

    [Fact]
    public async Task RunAsync_PropagatesException_FromWork()
    {
        var hooks = BuildHooks();
        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            hooks.RunAsync<string>("read_tool", isMutating: false, permissionCheck: null,
                work: () => throw new InvalidOperationException("boom")));
    }
}
