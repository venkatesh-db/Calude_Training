# Ticket: RxFlowOpsMcp — Real Jira Ops MCP Server (Hooks & Permissions)

Hand this whole file to whoever (or whatever agent) is building this project.
It's self-contained: context, exact requirements, gotchas already hit once,
and the acceptance bar. Following it should reproduce the project end to
end without re-discovering the same mistakes.

## Context

We want an MCP (Model Context Protocol) server, written in C#/.NET, that
lets an MCP client (Claude, an IDE assistant, etc.) read and act on **real**
Jira Service Management tickets — not mocked data — while every mutating
action passes through an explicit **permission gate**, and every tool call
(read or write) is observable through **hooks** (pre-call / post-call), so
there's an audit trail and a single choke point for rate limiting, logging,
or approval prompts later.

This is the kind of integration a support/ops team would actually run in
production: connect an AI agent to a real ticketing system, but never let
it mutate that system silently or outside an allow-listed scope.

## Goal

Build a real MCP server (`RxFlowOpsMcp`, stdio transport) exposing 8 tools
across two backends:

### Jira-backed tools (real Jira Cloud REST API v3, no mocking)

| Tool | Mutating? | Behavior |
|---|---|---|
| `get_ticket(issueKey)` | No | Fetch one issue by key, e.g. `SCRUM-1` |
| `search_incidents(jql, maxResults?)` | No | JQL search |
| `list_transitions(issueKey)` | No | Valid next-status transitions for a ticket |
| `create_change_request(projectKey, summary, description, issueType?)` | **Yes** | Creates an issue. `issueType` defaults to `"Change"` but must be overridable — see Gotcha #3 below |
| `update_ticket_status(issueKey, transitionId, comment?)` | **Yes** | Transitions a ticket using a `transitionId` from `list_transitions`, never a free-text status name |

### Ops-catalog tools (internal service metadata — real HTTP client, but no public spec exists)

| Tool | Mutating? | Behavior |
|---|---|---|
| `get_service_owner(serviceName)` | No | Owning team + on-call contact |
| `get_runbook(serviceName)` | No | Operational runbook for a service |
| `get_lab_health(labName)` | No | Current health status of a lab environment |

These three have no public API spec — Jira has no concept of "service
owner" or "runbook." Build them against a configurable
`OPS_CATALOG_BASE_URL` with a reasonable REST convention
(`GET /services/{id}/owner`, `/services/{id}/runbook`, `GET /labs/{id}/health`),
clearly documented as a placeholder to be corrected against the real
internal API once available. Do not silently mock these — fail loudly
(connection error) if no backend is configured, rather than returning fake
data.

## Requirements

1. **Real system connection** — Jira tools talk to the actual
   `https://<site>.atlassian.net/rest/api/3/...` API using API-token Basic
   auth, not a mock.
2. **Permissions** — `create_change_request` and `update_ticket_status`
   require an explicit project-key allow-list check *before* the HTTP call
   is made. The allow-list is config-driven (`appsettings.json`:
   `Jira:WritableProjects`). Calling a mutating tool against a project not
   on the allow-list is rejected with a clear error and makes **no** HTTP
   call.
3. **Hooks** — every tool call (read or write) goes through a pre-call hook
   (logs the request, runs the permission check if mutating) and a
   post-call hook (logs result/duration, win or lose). Implement this as
   one shared pipeline every tool routes through — not copy-pasted per
   tool.
4. **Config, not hardcoding** — Jira base URL/email/token via environment
   variables (`JIRA_BASE_URL`, `JIRA_EMAIL`, `JIRA_API_TOKEN`); writable
   project allow-list via `appsettings.json`; ops-catalog base URL/token via
   `OPS_CATALOG_BASE_URL` / `OPS_CATALOG_TOKEN`. Never hardcode secrets.
5. **stdout is reserved for the MCP protocol channel** — all logging must
   go to stderr.
6. **Fail fast, not silently** — a missing required env var should throw a
   clear exception when the relevant client is first used, not return fake
   data or crash the whole host at startup (constructing the HTTP clients
   lazily, only when a tool is actually invoked, is what lets the server
   still start and list its tools even before credentials are configured).

## Non-goals

- No auth/session management beyond a single API token from the
  environment.
- No web UI — this is a stdio MCP server for use from an MCP client config.
- No pagination beyond the first page of search results.
- No mocking of the ops-catalog data — if there's no real backend
  available yet, the tools should fail with a real connection error, not
  return canned data.

## Build steps (in order)

1. **Check the .NET SDK version first.** The MCP C# SDK
   (`ModelContextProtocol` NuGet package) needs **.NET 8+**. If the
   environment only has .NET 6, install .NET 8 to a user-scoped directory
   (no sudo needed, fully reversible):
   ```bash
   curl -sSL https://dot.net/v1/dotnet-install.sh -o dotnet-install.sh
   chmod +x dotnet-install.sh
   ./dotnet-install.sh --channel 8.0 --install-dir "$HOME/.dotnet8"
   export DOTNET_ROOT="$HOME/.dotnet8"; export PATH="$HOME/.dotnet8:$PATH"
   ```
2. **Read the current Jira API docs before writing the client** — don't
   guess from memorized patterns, APIs change. Confirm at minimum:
   - Auth header format:
     https://developer.atlassian.com/cloud/jira/platform/basic-auth-for-rest-apis/
     (`Authorization: Basic base64(email:api_token)`)
   - The search endpoint: the legacy `/rest/api/3/search` is
     deprecated/removed — use `POST /rest/api/3/search/jql` instead.
   - Issue/transition endpoints:
     `GET /rest/api/3/issue/{key}`, `POST /rest/api/3/issue`,
     `GET`/`POST /rest/api/3/issue/{key}/transitions`.
3. **Scaffold the project**: `dotnet new console`, add
   `ModelContextProtocol`, `Microsoft.Extensions.Hosting`,
   `Microsoft.Extensions.Http` NuGet packages. Target `net8.0`.
4. **Structure** (one type per file, mirrors a hooks+permissions MCP
   pattern used elsewhere in this workspace, `day6-mcp/GhIssuesMcp`):
   - `Program.cs` — host bootstrap: `AddConsole(o =>
     o.LogToStandardErrorThreshold = LogLevel.Trace)`, DI registration for
     `PermissionGate`, `ToolCallHooks`, `AddHttpClient<JiraClient>()`,
     `AddHttpClient<OpsCatalogClient>()`, `AddMcpServer().WithStdioServerTransport().WithToolsFromAssembly()`.
   - `PermissionGate.cs` — config-driven allow-list, throws
     `PermissionDeniedException` if the project key isn't listed.
   - `ToolCallHooks.cs` — `RunAsync<T>(toolName, isMutating, permissionCheck,
     work)` wrapping every tool call with pre/post logging and running the
     permission check before work only when mutating.
   - `JiraClient.cs` — real HTTP client, Basic auth from env vars, methods
     for get/search/create/transitions.
   - `OpsCatalogClient.cs` — real HTTP client, bearer auth from env vars,
     methods for owner/runbook/lab-health.
   - `RxFlowTools.cs` — the `[McpServerToolType]` class with all 8
     `[McpServerTool]`-attributed methods, each routing through
     `hooks.RunAsync`.
   - `appsettings.json` — `Jira:BaseUrl`, `Jira:WritableProjects`,
     `OpsCatalog:BaseUrl` (no secrets).
5. **Write tests** mirroring `day6-mcp/GhIssuesMcp.Tests`: xUnit project,
   `PermissionGate` tests (allows allow-listed, case-insensitive, blocks
   non-listed, blocks everything when empty) and `ToolCallHooks` tests
   (runs permission check before work, skips it for reads, propagates
   exceptions, returns work result).

## Gotchas already hit once — don't repeat these

1. **Jira `description`/`comment` fields are not plain strings.** Jira
   Cloud REST v3 requires Atlassian Document Format (ADF) — a `doc` node
   with `paragraph`/`text` content, not a bare string. Write a
   `PlainTextToAdf(string)` helper and use it for both issue descriptions
   and transition comments, or every create/comment call will 400.
2. **There is no public "dummy" Jira instance.** Jira API tokens are
   always tied to a real account/site. To test against something real
   without touching production, sign up for a **free Jira Cloud site**
   (https://www.atlassian.com/software/jira/free — no credit card). It's a
   real production API with sample seeded tickets, not a mock. The site's
   *space name* (e.g. "Bug Tracking") is **not** the project key used in
   API calls — query `GET /rest/api/3/project/search` to get the real key
   (often something like `SCRUM`), don't guess it from the space name.
3. **`"Change"` is not a universal Jira issue type.** It only exists on
   Jira Service Management projects with change management enabled. A
   plain software project (like a free-tier sample site) will only have
   `Epic`/`Subtask`/`Task`/`Story` and will 400 with
   `{"errors":{"issuetype":"Specify a valid issue type"}}` if you hardcode
   `"Change"`. Make `issueType` an optional parameter on
   `create_change_request`, defaulting to `"Change"` for real ITSM setups
   but overridable (e.g. `"Task"`) for everything else. Verify available
   types for a project via
   `GET /rest/api/3/issue/createmeta?projectKeys={KEY}` before assuming a
   type name is valid.
4. **Never paste API tokens directly into a chat/log that isn't a secret
   store.** Set them as local shell environment variables only, never write
   them into `appsettings.json` or any tracked file. If a token is ever
   pasted somewhere it shouldn't be, rotate it immediately at
   https://id.atlassian.com/manage/api-tokens — it costs nothing and takes
   seconds.
5. **Piping a static file of JSON-RPC lines into `dotnet run` via shell
   redirection can silently lose stdout** (buffering interacts badly with
   non-interactive stdin closing early), even though the server logs (on
   stderr) show it processed every request. Don't trust that as a "it's
   not working" signal. Instead drive it with a small script that spawns
   the server as a long-lived subprocess with real bidirectional pipes,
   writes one message at a time with an explicit flush, and reads
   line-by-line with a timeout — that's what an actual MCP client does
   anyway, so it's a more honest test.

## Acceptance criteria

- `dotnet build` succeeds with 0 warnings, 0 errors.
- `dotnet test` passes all `PermissionGate`/`ToolCallHooks` unit tests.
- Running the server and calling `get_ticket`/`search_incidents` against a
  real Jira site returns real, live ticket data (verified via the actual
  MCP `tools/call` protocol, not just a raw `curl` against Jira directly).
- Calling `create_change_request`/`update_ticket_status` against a project
  **not** in `Jira:WritableProjects` returns a permission-denied error and
  makes zero HTTP calls to Jira (confirm via the pre-call hook log line
  appearing and no `Sending HTTP request` line following it).
- Calling `create_change_request` against an **allow-listed** project with
  a valid `issueType` creates a real issue and returns its real key.
- Every tool call produces a pre-call and post-call log line to stderr,
  including elapsed time and success/failure status.
- Document every verification step and its actual output (not just "it
  works") in an `EXECUTION_LOG.md` alongside the project, so the proof is
  auditable later without re-running everything.

## MCP client config (once built)

```json
{
  "mcpServers": {
    "rxflow-ops": {
      "command": "dotnet",
      "args": ["run", "--project", "/absolute/path/to/RxFlowOpsMcp/RxFlowOpsMcp"],
      "env": {
        "JIRA_BASE_URL": "https://your-site.atlassian.net",
        "JIRA_EMAIL": "you@example.com",
        "JIRA_API_TOKEN": "your_jira_api_token",
        "OPS_CATALOG_BASE_URL": "https://ops-catalog.internal.example.com",
        "OPS_CATALOG_TOKEN": "your_ops_catalog_token",
        "DOTNET_ROOT": "/absolute/path/to/.dotnet8"
      }
    }
  }
}
```
