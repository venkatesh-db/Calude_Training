# RxFlowOpsMcp — Execution Log

A step-by-step record of how this server was built, verified, and run
against a real, live Jira Cloud site. Kept separate from `README.md` (which
documents *how to use* the project) so this stays a factual log of what was
actually executed and what came back.

---

## 1. Environment check

.NET SDK available on this machine was 6.0.400 — too old for the MCP C#
SDK (`ModelContextProtocol`), which needs .NET 8+.

```bash
dotnet --version && dotnet --list-sdks
```
```
6.0.400
6.0.201 [/usr/local/share/dotnet/sdk]
6.0.400 [/usr/local/share/dotnet/sdk]
```

**Action:** installed .NET 8 SDK to a user-scoped directory (no sudo, fully
reversible):

```bash
curl -sSL https://dot.net/v1/dotnet-install.sh -o dotnet-install.sh
chmod +x dotnet-install.sh
./dotnet-install.sh --channel 8.0 --install-dir "$HOME/.dotnet8"
```
```
dotnet-install: .NET Core SDK with version '8.0.424' is already installed.
```

Confirmed at `~/.dotnet8/sdk/8.0.424`.

---

## 2. Project scaffold

Found an existing sibling project in this workspace,
[`day6-mcp/GhIssuesMcp`](../day6-mcp/GhIssuesMcp), that already implements
the exact pattern needed (stdio MCP server, `PermissionGate` allow-list,
`ToolCallHooks` pre/post-call pipeline) against GitHub Issues. Reused that
structure and ported it to Jira Service Management:

| File | Purpose |
|---|---|
| `RxFlowOpsMcp/Program.cs` | Host bootstrap, DI registration, stdio transport |
| `RxFlowOpsMcp/PermissionGate.cs` | Config-driven allow-list gating mutating calls |
| `RxFlowOpsMcp/ToolCallHooks.cs` | Pre-call/post-call logging pipeline every tool routes through |
| `RxFlowOpsMcp/JiraClient.cs` | Real Jira Cloud REST API v3 client (issues, search, transitions) |
| `RxFlowOpsMcp/OpsCatalogClient.cs` | Client for internal service-owner/runbook/lab-health API |
| `RxFlowOpsMcp/RxFlowTools.cs` | The 8 `[McpServerTool]`-attributed tool definitions |
| `RxFlowOpsMcp.Tests/*` | xUnit tests for `PermissionGate` and `ToolCallHooks` |

Before writing the Jira client, fetched current Atlassian docs (not
memorized/guessed patterns, per project convention) to confirm:
- Auth: `Authorization: Basic base64(email:api_token)` —
  https://developer.atlassian.com/cloud/jira/platform/basic-auth-for-rest-apis/
- Search: legacy `/rest/api/3/search` is deprecated/removed; current
  endpoint is `POST /rest/api/3/search/jql`
- Issue CRUD/transitions: `GET /rest/api/3/issue/{key}`,
  `POST /rest/api/3/issue`, `POST /rest/api/3/issue/{key}/transitions`

---

## 3. Build

```bash
export DOTNET_ROOT="$HOME/.dotnet8"; export PATH="$HOME/.dotnet8:$PATH"
cd RxFlowOpsMcp/RxFlowOpsMcp
dotnet build
```
```
Restored /Users/venkatesh/Calude_smilebatch/RxFlowOpsMcp/RxFlowOpsMcp/RxFlowOpsMcp.csproj (in 1.95 sec).
RxFlowOpsMcp -> /Users/venkatesh/Calude_smilebatch/RxFlowOpsMcp/RxFlowOpsMcp/bin/Debug/net8.0/RxFlowOpsMcp.dll

Build succeeded.
    0 Warning(s)
    0 Error(s)
```

---

## 4. Unit tests

```bash
cd RxFlowOpsMcp/RxFlowOpsMcp.Tests
dotnet test
```
```
Passed!  - Failed: 0, Passed: 12, Skipped: 0, Total: 12, Duration: 38 ms - RxFlowOpsMcp.Tests.dll (net8.0)
```

Covered:
- `PermissionGate.EnsureWritable` — allows an allow-listed project,
  case-insensitive match, blocks a non-listed project, blocks everything
  when the allow-list is empty
- `PermissionGate.ProjectKeyOf` — extracts `OPS` from `OPS-4821`, throws on
  a malformed key
- `ToolCallHooks.RunAsync` — returns work result for reads, runs the
  permission check *before* work for mutating calls and never runs work if
  it throws, skips the permission check entirely for reads, propagates
  exceptions from the work delegate

---

## 5. Server startup smoke test (no live calls)

```bash
echo "" | dotnet run
```
Server started, read stdio to EOF, and shut down cleanly — no crash on
startup even with `JIRA_*`/`OPS_CATALOG_*` env vars unset, because those
clients are constructed lazily (only when a tool is first invoked), not at
host startup. This confirmed the process wiring before any real credentials
were involved.

---

## 6. Getting a real Jira site to test against

No public Jira instance grants API access without an account, so a **free
Jira Cloud site** was created (not mocked — this is the same production
API a paid site uses, just empty/sample data):

1. Signed up at jira.atlassian.com/software/jira/free
2. Site created: `https://venkateshdb.atlassian.net`
3. Named the default space "Bug Tracking" (space name, not the project key)
4. Generated an API token at
   https://id.atlassian.com/manage/api-tokens

⚠️ The API token was pasted directly into chat during this session. It was
used only for the verification below, was never written into any tracked
file, and **the user was advised to revoke and rotate it** after testing.

---

## 7. Verifying the real project key (read-only)

The space name ("Bug Tracking") is not the same as the Jira **project
key** used in API calls, so this was queried directly rather than guessed:

```bash
curl -s -H "Authorization: Basic $(printf '%s:%s' "$JIRA_EMAIL" "$JIRA_API_TOKEN" | base64)" \
  -H "Accept: application/json" \
  "$JIRA_BASE_URL/rest/api/3/project/search"
```

Result: one real project, key **`SCRUM`**, name "Bug Tracking", id `10000`.

---

## 8. Verifying real ticket data via raw API (read-only)

```bash
curl -s -X POST -H "Content-Type: application/json" \
  -H "Authorization: Basic ..." \
  -d '{"jql":"project = SCRUM ORDER BY created DESC","maxResults":10,"fields":["summary","status","issuetype"]}' \
  "$JIRA_BASE_URL/rest/api/3/search/jql"
```

Returned 5 real, live tickets:

| Key | Summary | Type | Status |
|---|---|---|---|
| SCRUM-5 | Implement this work item from your IDE or terminal | Subtask | To Do |
| SCRUM-4 | Delegate this work item to Claude | Subtask | To Do |
| SCRUM-3 | Connect Atlassian Rovo MCP to your local coding tools | Task | To Do |
| SCRUM-2 | Connect Claude to Jira | Task | To Do |
| SCRUM-1 | Start here: Add your team's work | Task | To Do |

This proved the auth scheme and endpoint shape used in `JiraClient.cs` are
correct against the real API before wiring the MCP layer.

---

## 9. Configuring the server for this real site

Edited `RxFlowOpsMcp/appsettings.json`:

```diff
   "Jira": {
-    "BaseUrl": "https://your-domain.atlassian.net",
+    "BaseUrl": "https://venkateshdb.atlassian.net",
     "WritableProjects": [
-      "OPS"
+      "SCRUM"
     ]
   },
```

Credentials (`JIRA_EMAIL`, `JIRA_API_TOKEN`) were kept out of any tracked
file — set only as local shell environment variables for the test runs
below.

Rebuilt + re-ran the test suite after the config change: build succeeded,
12/12 tests still passing (the tests use in-memory config, unaffected by
`appsettings.json`).

---

## 10. Driving the actual MCP server over stdio (not raw curl)

First attempt piped a static file of JSON-RPC lines into `dotnet run` via
shell redirection — the process read and processed the requests (confirmed
via stderr logs: `method 'tools/call' request handler called` appeared
twice) but stdout capture came back empty, most likely an artifact of
non-interactive stdin closing before the buffered stdout was flushed back
through that particular piping method.

**Fix:** wrote a small Python driver
(`mcp_client.py`) that spawns the server as a long-lived subprocess with
real bidirectional pipes, writes one JSON-RPC message at a time with an
explicit flush, and reads line-by-line with a timeout — closer to how a
real MCP client (Claude Desktop, VS Code, etc.) actually talks to a stdio
server.

```bash
python3 mcp_client.py
```

### 10a. `initialize`

```json
{"result":{"protocolVersion":"2024-11-05","capabilities":{"logging":{},"tools":{"listChanged":true}},"serverInfo":{"name":"RxFlowOpsMcp","version":"1.0.0.0"}},"id":1,"jsonrpc":"2.0"}
```

### 10b. `tools/list`

All 8 tools returned with full JSON-Schema `inputSchema`s: `get_ticket`,
`search_incidents`, `get_service_owner`, `get_runbook`, `get_lab_health`,
`list_transitions`, `create_change_request`, `update_ticket_status`.

### 10c. `tools/call` → `get_ticket(issueKey="SCRUM-1")`

Returned the full, real Jira issue payload for SCRUM-1 — summary "Start
here: Add your team's work", status "To Do", reporter/creator
`venkatesh db` (`venkatesh.db@gmail.com`), real timestamps, real
attachment metadata, real sprint info ("SCRUM Sprint 0"). `isError: false`.

### 10d. `tools/call` → `search_incidents(jql="project = SCRUM ORDER BY created DESC", maxResults=5)`

Returned all 5 real tickets (`SCRUM-1`…`SCRUM-5`) with summary/status per
issue, matching what the raw `curl` call in step 8 showed. `isError: false`.

### 10e. `tools/call` → `create_change_request(projectKey="NOTALLOWED", summary="x", description="y")`

```json
{"result":{"content":[{"type":"text","text":"An error occurred invoking 'create_change_request'."}],"isError":true},"id":5,"jsonrpc":"2.0"}
```

**This is the expected, correct outcome.** `PermissionGate.EnsureWritable`
threw a `PermissionDeniedException` before any HTTP call was made to Jira —
confirmed by there being no corresponding write in Jira and by
`ToolCallHooks`'s pre-call/post-call log lines on stderr showing the error
path. No ticket was created.

---

## 11. Real write test: `create_change_request` against the allow-listed `SCRUM` project

Run with explicit user go-ahead ("run one real write against SCRUM to close
out item 1").

### 11a. First attempt — failed, but correctly

```json
{"name": "create_change_request", "arguments": {
  "projectKey": "SCRUM",
  "summary": "[RxFlowOpsMcp test] Verify MCP server can create real change requests",
  "description": "..."
}}
```
```json
{"result":{"content":[{"type":"text","text":"An error occurred invoking 'create_change_request'."}],"isError":true},"id":2,"jsonrpc":"2.0"}
```

The generic MCP-level message hid the real cause, but stderr showed it
clearly — this was a genuine, real HTTP round trip to Jira, not an internal
bug:

```
[pre-call] tool=CreateChangeRequest mutating=True
Sending HTTP request POST https://venkateshdb.atlassian.net/rest/api/3/issue
Received HTTP response headers after 1056.7107ms - 400
[post-call] tool=CreateChangeRequest status=error elapsedMs=1081
  error=Jira API call to create change request failed with 400 Bad Request:
  {"errorMessages":[],"errors":{"issuetype":"Specify a valid issue type"}}
```

**Root cause:** the tool defaulted to Jira issue type `"Change"`, which
only exists on Jira Service Management projects with change management
enabled. `SCRUM` is a plain software project. Verified the project's actual
issue types via `GET /rest/api/3/issue/createmeta?projectKeys=SCRUM`:

```
Epic
Subtask
Task
Story
```

**Fix:** added an optional `issueType` parameter to the `create_change_request`
tool (`RxFlowTools.cs`), defaulting to `"Change"` for real ITSM projects but
overridable for projects that don't have that type. Rebuilt (0
warnings/errors) and re-ran the test suite (still 12/12 passing) after the
change.

### 11b. Retry with `issueType: "Task"` — succeeded

```json
{"name": "create_change_request", "arguments": {
  "projectKey": "SCRUM",
  "summary": "[RxFlowOpsMcp test] Verify MCP server can create real change requests",
  "description": "This ticket was created by the RxFlowOpsMcp MCP server's create_change_request tool as a live end-to-end test. Safe to close/delete.",
  "issueType": "Task"
}}
```

**Result: a real ticket was created on the live site —
[`SCRUM-6`](https://venkateshdb.atlassian.net/browse/SCRUM-6)**, "[RxFlowOpsMcp
test] Verify MCP server can create real change requests", status "To Do",
reporter `venkatesh db`, `isError: false`.

This closes out the one previously-open item: a real, allow-listed
mutating write, executed through the actual MCP tool (not raw `curl`), has
now been proven end to end — request → permission check pass → real Jira
POST → real created issue → real issue key returned to the client.

## 12. What is still not executed live

- `update_ticket_status` — not yet run against a real ticket (e.g.
  transitioning `SCRUM-6` using a `transitionId` from `list_transitions`).
- `get_service_owner`, `get_runbook`, `get_lab_health` — these hit
  `OpsCatalogClient`, which needs a real internal ops-catalog API.
  `OPS_CATALOG_BASE_URL` was pointed at `http://localhost:1` (a guaranteed
  connection-refused address) for the smoke tests above specifically so
  these tools were not exercised; there is no live backend for them yet.

## 13. Follow-up: rotate the leaked token

The Jira API token used for steps 7–10 was pasted into chat during this
session. It was used only for the read-only/gated calls documented above,
was never written into `appsettings.json`, `.env`, or any other tracked
file, and should be revoked and replaced:
https://id.atlassian.com/manage/api-tokens
