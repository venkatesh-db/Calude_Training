# RxFlowOpsMcp

A minimal, real MCP server (stdio transport, C#/.NET 8) exposing RxFlow
operations as MCP tools, with a permission gate on mutating calls and a
hooks pipeline that logs every call — same pattern as
[`../day6-mcp/GhIssuesMcp`](../day6-mcp/GhIssuesMcp), applied to Jira
Service Management instead of GitHub Issues.

## What's real vs. what you must wire up

- **Tickets/incidents** (`get_ticket`, `search_incidents`,
  `create_change_request`, `list_transitions`, `update_ticket_status`) call
  the real **Jira Cloud REST API v3** (`api.github.com`-style, but
  `your-domain.atlassian.net/rest/api/3/...`), authenticated with an API
  token — no mocking.
- **Ops metadata** (`get_service_owner`, `get_runbook`, `get_lab_health`)
  calls a configurable internal "ops catalog" API. There's no public spec
  for this kind of internal service, so [`OpsCatalogClient.cs`](RxFlowOpsMcp/OpsCatalogClient.cs)
  uses a reasonable REST convention (`GET /services/{id}/owner`, etc.) —
  point `OPS_CATALOG_BASE_URL` at your real internal API and adjust the
  paths/auth in that file if your API differs.

## Requirements

- .NET 8 SDK (this machine only had .NET 6 — installed 8 to
  `~/.dotnet8` via the official `dotnet-install.sh` script; add it to
  `PATH`/`DOTNET_ROOT` or reinstall system-wide as you prefer)
- A Jira Cloud API token: https://id.atlassian.com/manage/api-tokens
- Your internal ops-catalog API's base URL + bearer token

## Setup

```bash
export JIRA_BASE_URL=https://your-domain.atlassian.net
export JIRA_EMAIL=you@company.com
export JIRA_API_TOKEN=your_jira_api_token
export OPS_CATALOG_BASE_URL=https://ops-catalog.internal.example.com
export OPS_CATALOG_TOKEN=your_ops_catalog_token
```

Edit `RxFlowOpsMcp/appsettings.json` to list the Jira projects mutating
tools are allowed to touch:

```json
{
  "Jira": {
    "WritableProjects": ["OPS"]
  }
}
```

## Build & run

```bash
cd RxFlowOpsMcp
dotnet build
dotnet run
```

Point an MCP client at it, e.g. in `claude_desktop_config.json` / `.mcp.json`:

```json
{
  "servers": {
    "rxflow-ops": {
      "type": "stdio",
      "command": "dotnet",
      "args": ["run", "--project", "/absolute/path/to/RxFlowOpsMcp/RxFlowOpsMcp"],
      "env": {
        "JIRA_BASE_URL": "https://your-domain.atlassian.net",
        "JIRA_EMAIL": "you@company.com",
        "JIRA_API_TOKEN": "your_jira_api_token",
        "OPS_CATALOG_BASE_URL": "https://ops-catalog.internal.example.com",
        "OPS_CATALOG_TOKEN": "your_ops_catalog_token"
      }
    }
  }
}
```

## Tools

| Tool | Mutating? | Notes |
|---|---|---|
| `get_ticket(issueKey)` | No | Real Jira issue by key, e.g. `OPS-123` |
| `search_incidents(jql, maxResults?)` | No | Real JQL search via `/rest/api/3/search/jql` |
| `get_service_owner(serviceName)` | No | Internal ops catalog |
| `get_runbook(serviceName)` | No | Internal ops catalog |
| `get_lab_health(labName)` | No | Internal ops catalog |
| `list_transitions(issueKey)` | No | Valid next-status transitions for a ticket |
| `create_change_request(projectKey, summary, description)` | **Yes** | Blocked unless `projectKey` is in `Jira:WritableProjects` |
| `update_ticket_status(issueKey, transitionId, comment?)` | **Yes** | Blocked unless the ticket's project is in `Jira:WritableProjects`; requires a `transitionId` from `list_transitions`, not a free-text name |

## How hooks & permissions work

- `ToolCallHooks.RunAsync` wraps every tool call: logs a pre-call line,
  runs an optional permission check for mutating calls, runs the actual
  work, then logs a post-call line with elapsed time and success/failure —
  win or lose, to stderr (stdout is reserved for the MCP protocol).
- `PermissionGate.EnsureWritable` throws before any HTTP write is made if
  the Jira project isn't in the `Jira:WritableProjects` allow-list. Read
  tools never call it. This is the mechanical stand-in for "approval before
  any external write" — in a client like Claude, the human still approves
  the tool call itself before it runs; the allow-list is the second,
  server-side gate that can't be bypassed by prompt injection.

## The full loop, end to end

This server is built to support the 9-step incident-response loop:

1. **Retrieve a defect** — `get_ticket("OPS-4821")`
2. **Search previous incidents** — `search_incidents("project = OPS AND issuetype = Incident AND text ~ \"ingest timeout\" ORDER BY created DESC")`
3. **Read the service runbook** — `get_runbook("rxflow-ingest")`
4. **Check service ownership** — `get_service_owner("rxflow-ingest")`
5. **Investigate the repository** — done by the MCP *client* (Claude) using
   its normal file/code tools against the actual repo — not an MCP tool
   here, since repo access is already available to the agent.
6. **Produce a patch** — same: the client writes the fix using its own
   editing tools, informed by steps 1–5.
7. **Prepare a change request** — draft the CR text, then call
   `list_transitions` if needed and hold the actual write for step 8.
8. **Request approval before any external write** — the MCP client asks
   the human to confirm before calling `create_change_request`. Even if
   approved, the call still fails server-side unless the project is
   allow-listed in `appsettings.json`.
9. **Update status only after verification** — after the fix is verified
   (tests pass, deploy confirmed, etc.), call `list_transitions("OPS-4821")`
   to get the valid transition id, then
   `update_ticket_status("OPS-4821", "31", comment: "Fix verified in staging, closing.")`.

Steps 5–6 and 8's "ask the human" behavior live in your MCP client's
prompt/workflow, not in this server — the server's job is to make sure the
*writes* (step 8's CR creation, step 9's status change) are impossible
against a project nobody explicitly allow-listed, no matter what the model
decides to do.

## Try it

```bash
dotnet build   # 0 warnings, 0 errors as of this scaffold
# then wire into an MCP client and call, e.g.:
#   get_ticket(issueKey="OPS-4821")
#   search_incidents(jql="project = OPS AND issuetype = Incident ORDER BY created DESC", maxResults=10)
#   create_change_request(projectKey="NOTALLOWED", summary="x", description="y")
#     -> permission-denied error, since NOTALLOWED isn't allow-listed
```
