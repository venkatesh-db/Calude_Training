# Ticket: RxFlowOpsMcp — Real Azure DevOps Ops MCP Server (Hooks & Permissions)

Hand this whole file to whoever (or whatever agent) is building this project.
It's self-contained: context, exact requirements, gotchas already hit once,
and the acceptance bar. Following it should reproduce the project end to
end without re-discovering the same mistakes.

## Context

We want an MCP (Model Context Protocol) server, written in C#/.NET, that
lets an MCP client (Claude, an IDE assistant, etc.) read and act on **real**
Azure Boards work items — not mocked data — while every mutating action
passes through an explicit **permission gate**, and every tool call (read
or write) is observable through **hooks** (pre-call / post-call), so
there's an audit trail and a single choke point for rate limiting,
logging, or approval prompts later.

This mirrors an existing sibling project in this workspace,
[`../RxFlowOpsMcp-Jira`](../RxFlowOpsMcp-Jira), with Jira Service
Management swapped for Azure DevOps — same hooks/permission-gate skeleton,
different backend. If that project already exists, copy its structure
file-for-file and only change the ticket-system client; don't redesign the
pattern.

This is the kind of integration a support/ops team would actually run in
production: connect an AI agent to a real ticketing system, but never let
it mutate that system silently or outside an allow-listed scope, and
require a human to approve the mutation before it happens.

## Goal

Build a real MCP server (`RxFlowOpsMcp`, stdio transport) exposing 8 tools
across two backends:

### Azure DevOps–backed tools (real Azure DevOps REST API v7.1, no mocking)

| Tool | Mutating? | Behavior |
|---|---|---|
| `get_ticket(workItemId)` | No | Fetch one work item by numeric id |
| `search_incidents(wiql, maxResults?)` | No | WIQL query, hydrated via the batch endpoint |
| `list_valid_states(workItemType)` | No | Valid `System.State` values for a work item type (Azure DevOps' equivalent of Jira's "list transitions" — there's no generic transitions endpoint, so this reads the work item type's state definitions instead) |
| `create_change_request(project, title, description, workItemType?)` | **Yes** | Creates a work item. `workItemType` defaults to `"Change Request"` but must be overridable — most process templates don't have that type out of the box |
| `update_ticket_status(workItemId, newState, comment?)` | **Yes** | Sets `System.State` via a JSON Patch `PATCH`, optionally appending a comment via `System.History` |

### Ops-catalog tools (internal service metadata — real HTTP client, with a mock fallback)

| Tool | Mutating? | Behavior |
|---|---|---|
| `get_service_owner(serviceName)` | No | Owning team + on-call contact |
| `get_runbook(serviceName)` | No | Operational runbook for a service |
| `get_lab_health(labName)` | No | Current health status of a lab environment |

These three have no public API spec — Azure Boards has no concept of
"service owner" or "runbook." Build them against a configurable
`OPS_CATALOG_BASE_URL` with a reasonable REST convention
(`GET /services/{id}/owner`, `/services/{id}/runbook`,
`GET /labs/{id}/health`), clearly documented as a placeholder to be
corrected against the real internal API once available. **Unlike the pure
Jira version, also add an explicit mock mode** (`OPS_CATALOG_MOCK=true` /
`OpsCatalog:Mock` config) that returns canned-but-realistic data with zero
HTTP calls — useful so the other, real Azure DevOps tools aren't blocked
on a second backend existing. Mock mode must be opt-in and clearly labeled
in code/README as fake data, never silently substituted.

## Requirements

1. **Real system connection** — Azure DevOps tools talk to the actual
   `https://dev.azure.com/{organization}/{project}/_apis/wit/...` API v7.1
   using PAT Basic auth (empty username, PAT as password), not a mock.
2. **Permissions** — `create_change_request` and `update_ticket_status`
   require an explicit project allow-list check *before* the HTTP call is
   made. The allow-list is config-driven (`appsettings.json`:
   `AzureDevOps:WritableProjects`). Calling a mutating tool against a
   project not on the allow-list is rejected with a clear error and makes
   **no** HTTP call.
3. **Human approval before any external write** — the allow-list is the
   server-side half of this; the MCP client (Claude) asking the human to
   confirm before invoking `create_change_request`/`update_ticket_status`
   is the client-side half. Document this split clearly — the server
   cannot force the client to ask, but it can make sure the write is
   impossible even if asked and approved against an out-of-scope project.
4. **Hooks** — every tool call (read or write) goes through a pre-call hook
   (logs the request, runs the permission check if mutating) and a
   post-call hook (logs result/duration, win or lose). Implement this as
   one shared pipeline every tool routes through — not copy-pasted per
   tool.
5. **Config, not hardcoding** — Azure DevOps org/project/PAT via
   environment variables (`AZDO_ORG`, `AZDO_PROJECT`, `AZDO_PAT`); writable
   project allow-list via `appsettings.json`; ops-catalog base URL/token
   via `OPS_CATALOG_BASE_URL` / `OPS_CATALOG_TOKEN` (or `OPS_CATALOG_MOCK`).
   Never hardcode secrets.
6. **stdout is reserved for the MCP protocol channel** — all logging must
   go to stderr.
7. **Fail fast, not silently** — a missing required env var should throw a
   clear exception when the relevant client is first constructed, not
   return fake data or crash the whole host at startup.

## Non-goals

- No auth/session management beyond a single PAT from the environment.
- No web UI — this is a stdio MCP server for use from an MCP client config.
- No pagination beyond the first page of WIQL search results.
- No silent mocking of Azure DevOps itself — only the internal ops-catalog
  piece gets an opt-in mock; the ticket system is always real.

## Build steps (in order)

1. **Check the .NET SDK version first.** The MCP C# SDK
   (`ModelContextProtocol` NuGet package) needs **.NET 8+**. If the
   environment only has an older SDK, install .NET 8 to a user-scoped
   directory (no sudo needed, fully reversible):
   ```bash
   curl -sSL https://dot.net/v1/dotnet-install.sh -o dotnet-install.sh
   chmod +x dotnet-install.sh
   ./dotnet-install.sh --channel 8.0 --install-dir "$HOME/.dotnet8"
   export DOTNET_ROOT="$HOME/.dotnet8"; export PATH="$HOME/.dotnet8:$PATH"
   ```
2. **Read the current Azure DevOps REST API docs before writing the
   client** — don't guess from memorized patterns. Confirm at minimum:
   - Auth: PAT over Basic auth with an **empty username** —
     `Authorization: Basic base64(":" + pat)`.
   - Work item read: `GET /{project}/_apis/wit/workitems/{id}?api-version=7.1`.
   - Search: there is **no free-text search endpoint** — use WIQL:
     `POST /{project}/_apis/wit/wiql?api-version=7.1` with `{"query": "..."}`,
     which returns only `{id, url}` pairs, then hydrate fields via
     `POST /_apis/wit/workitemsbatch?api-version=7.1` (org-level, not
     project-scoped) with `{ids, fields}`.
   - Create: `POST /{project}/_apis/wit/workitems/${type}?api-version=7.1`
     with `Content-Type: application/json-patch+json` and a JSON Patch body
     (`[{op:"add", path:"/fields/System.Title", value:...}, ...]`).
   - Update/transition: `PATCH /{project}/_apis/wit/workitems/{id}?api-version=7.1`,
     same JSON Patch content type, patching `/fields/System.State` (and
     optionally `/fields/System.History` for a comment).
   - Valid states for a type: `GET /{project}/_apis/wit/workitemtypes/{type}/states?api-version=7.1`.
3. **Scaffold the project**: `dotnet new console`, add
   `ModelContextProtocol`, `Microsoft.Extensions.Hosting`,
   `Microsoft.Extensions.Http` NuGet packages. Target `net8.0`.
4. **Structure** (one type per file, matching the Jira sibling project):
   - `Program.cs` — host bootstrap: `AddConsole(o =>
     o.LogToStandardErrorThreshold = LogLevel.Trace)`, DI registration for
     `PermissionGate`, `ToolCallHooks`,
     `AddHttpClient<AzureDevOpsClient>()`, `AddHttpClient<OpsCatalogClient>()`,
     `AddMcpServer().WithStdioServerTransport().WithToolsFromAssembly()`.
   - `PermissionGate.cs` — config-driven allow-list, throws
     `PermissionDeniedException` if the project isn't listed.
   - `ToolCallHooks.cs` — `RunAsync<T>(toolName, isMutating, permissionCheck,
     work)` wrapping every tool call with pre/post logging and running the
     permission check before work only when mutating.
   - `AzureDevOpsClient.cs` — real HTTP client, PAT Basic auth from env
     vars, methods for get/search(WIQL+batch)/create/update/list-states.
     Expose the configured project as a public `DefaultProject` property so
     tools that don't take an explicit project param (like
     `update_ticket_status`) can still run the permission check.
   - `OpsCatalogClient.cs` — real HTTP client, bearer auth from env vars,
     with an `OPS_CATALOG_MOCK` opt-in path returning canned data instead
     of making HTTP calls.
   - `RxFlowTools.cs` — the `[McpServerToolType]` class with all 8
     `[McpServerTool]`-attributed methods, each routing through
     `hooks.RunAsync`.
   - `appsettings.json` — `AzureDevOps:Organization`,
     `AzureDevOps:Project`, `AzureDevOps:WritableProjects`,
     `OpsCatalog:Mock`, `OpsCatalog:BaseUrl` (no secrets).
5. **Write tests** mirroring the Jira sibling project: xUnit project,
   `PermissionGate` tests (allows allow-listed, case-insensitive, blocks
   non-listed, blocks everything when empty) and `ToolCallHooks` tests
   (runs permission check before work, skips it for reads, propagates
   exceptions, returns work result).

## Gotchas already hit once — don't repeat these

1. **Azure DevOps and the Azure Portal are different products with
   different signup flows.** Signing into `portal.azure.com` does **not**
   give you an Azure DevOps organization. Go to `https://dev.azure.com`
   directly — if that redirects to a marketing page instead of the app,
   use `https://aex.dev.azure.com/` to reach the actual "Create new
   organization" screen.
2. **Creating an Azure DevOps org now requires linking an Azure
   subscription for billing**, even though Azure DevOps itself (Basic
   plan, 5 users) is free. If the account has no subscription, click "Get
   started with Azure" to create the free, spending-limit-protected Azure
   Free Account — it won't charge unless explicitly upgraded, but it does
   ask for card verification. Don't be surprised by this step; it's not
   optional for a fresh Microsoft account.
3. **There is no generic "list transitions" endpoint like Jira's.** Azure
   DevOps work item state machines are defined per work item type. Use
   `GET /_apis/wit/workitemtypes/{type}/states` to get valid state names
   before calling the update tool, instead of a per-ticket transitions
   list.
4. **`workitemsbatch` is an org-level endpoint, not project-scoped** — call
   it as `POST /_apis/wit/workitemsbatch`, not
   `POST /{project}/_apis/wit/workitemsbatch`, or it 404s.
5. **`"Change Request"` is not a default work item type on Basic/Agile
   process templates.** It only exists if your process template defines
   it. Make `workItemType` an optional parameter on
   `create_change_request`, defaulting to `"Change Request"` but
   overridable (e.g. `"Task"` or `"Issue"`, which the Basic process
   template does have) for everything else.
6. **Never paste API tokens directly into a chat/log that isn't a secret
   store.** Set them as local shell environment variables or directly in
   your MCP client's config file only, never write them into
   `appsettings.json` or any tracked file. If a token is ever pasted
   somewhere it shouldn't be, rotate it immediately at
   `https://dev.azure.com/{org}/_usersSettings/tokens` — it costs nothing
   and takes seconds. Treat "pasted into a chat session" as compromised
   even if that session feels private.
7. **Piping a static file of JSON-RPC lines into `dotnet run` via shell
   redirection can silently lose stdout** (buffering interacts badly with
   non-interactive stdin closing early), even though the server logs (on
   stderr) show it processed every request. Instead spawn the server as a
   background subprocess, write the JSON-RPC lines to its stdin with a
   trailing `sleep` to let it flush, then read the captured stdout file —
   closer to what a real MCP client's bidirectional pipe does anyway.
8. **This machine's default `dotnet` may be an older SDK** (e.g. 6.0) even
   after installing 8.0 to `~/.dotnet8` — always export `DOTNET_ROOT` and
   prepend `~/.dotnet8` to `PATH` before `dotnet build`/`run`/`test`, or
   you'll get `NETSDK1045: does not support targeting .NET 8.0`.

## Acceptance criteria

- `dotnet build` succeeds with 0 warnings, 0 errors.
- `dotnet test` passes all `PermissionGate`/`ToolCallHooks` unit tests.
- Running the server and calling `get_ticket` against a real Azure DevOps
  project returns real, live work item data (verified via the actual MCP
  `tools/call` protocol, not just a raw `curl` against Azure DevOps
  directly).
- Calling `get_service_owner`/`get_runbook`/`get_lab_health` with
  `OPS_CATALOG_MOCK=true` returns canned data with zero HTTP calls.
- Calling `create_change_request`/`update_ticket_status` against a project
  **not** in `AzureDevOps:WritableProjects` returns a permission-denied
  error and makes zero HTTP calls to Azure DevOps (confirm via the
  pre-call hook log line appearing and no `Sending HTTP request` line
  following it).
- Calling `create_change_request` against an **allow-listed** project with
  a valid `workItemType` creates a real work item and returns its real id.
- Every tool call produces a pre-call and post-call log line to stderr,
  including elapsed time and success/failure status.

## The full 9-step loop this server supports

1. **Retrieve a defect** — `get_ticket(workItemId)`
2. **Search previous incidents** — `search_incidents(wiql)`
3. **Read the service runbook** — `get_runbook(serviceName)`
4. **Check service ownership** — `get_service_owner(serviceName)`
5. **Investigate the repository** — done by the MCP client's own file/code
   tools, not this server.
6. **Produce a patch** — same, client-side.
7. **Prepare a change request** — draft the text, call `list_valid_states`
   if needed, hold the write for step 8.
8. **Request approval before any external write** — the MCP client asks
   the human to confirm before calling `create_change_request`. Even if
   approved, the call still fails server-side unless the project is
   allow-listed.
9. **Update status only after verification** — call
   `list_valid_states(workItemType)` to get a valid state name, then
   `update_ticket_status(workItemId, newState, comment)`.

## MCP client config (once built)

```json
{
  "mcpServers": {
    "rxflow-ops-azure": {
      "type": "stdio",
      "command": "dotnet",
      "args": ["run", "--project", "/absolute/path/to/RxFlowOpsMcp-Azure/RxFlowOpsMcp"],
      "env": {
        "DOTNET_ROOT": "/absolute/path/to/.dotnet8",
        "PATH": "/absolute/path/to/.dotnet8:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin",
        "AZDO_ORG": "your-azdo-org",
        "AZDO_PROJECT": "RxFlow",
        "AZDO_PAT": "your_personal_access_token",
        "OPS_CATALOG_MOCK": "true"
      }
    }
  }
}
```

Swap `OPS_CATALOG_MOCK: "true"` for real `OPS_CATALOG_BASE_URL` /
`OPS_CATALOG_TOKEN` once you have an actual internal ops-catalog API.
