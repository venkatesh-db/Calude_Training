const pptxgen = require('pptxgenjs');
const path = require('path');
const html2pptx = require('./html2pptx');

async function build() {
  const pptx = new pptxgen();
  pptx.layout = 'LAYOUT_16x9';
  pptx.author = 'RxFlowOpsMcp';
  pptx.title = 'RxFlowOpsMcp on Azure DevOps — Project Benefits';

  await html2pptx(path.join(__dirname, '1-title.html'), pptx);
  await html2pptx(path.join(__dirname, '2-benefits.html'), pptx);
  await html2pptx(path.join(__dirname, '3-architecture.html'), pptx);
  await html2pptx(path.join(__dirname, '4-loop.html'), pptx);

  const { slide, placeholders } = await html2pptx(path.join(__dirname, '5-proof.html'), pptx);
  const toolsArea = placeholders.find(p => p.id === 'tools');

  const tableData = [
    [
      { text: 'Tool', options: { fill: { color: '0F1B2A' }, color: 'FFFFFF', bold: true } },
      { text: 'Mutating?', options: { fill: { color: '0F1B2A' }, color: 'FFFFFF', bold: true } }
    ],
    ['get_ticket', 'No'],
    ['search_incidents', 'No'],
    ['get_service_owner', 'No'],
    ['get_runbook', 'No'],
    ['get_lab_health', 'No'],
    ['list_valid_states', 'No'],
    [{ text: 'create_change_request', options: { color: '8A5A00' } }, { text: 'Yes — gated', options: { color: '8A5A00', bold: true } }],
    [{ text: 'update_ticket_status', options: { color: '8A5A00' } }, { text: 'Yes — gated', options: { color: '8A5A00', bold: true } }]
  ];

  slide.addTable(tableData, {
    ...toolsArea,
    colW: [2.6, 1.2],
    border: { pt: 0.75, color: 'C9D3D8' },
    align: 'left',
    valign: 'middle',
    fontSize: 10,
    fontFace: 'Arial'
  });

  const outPath = path.join(__dirname, '..', 'RxFlowOpsMcp-Azure_Benefits.pptx');
  await pptx.writeFile({ fileName: outPath });
  console.log('Wrote', outPath);
}

build().catch(e => { console.error(e); process.exit(1); });
