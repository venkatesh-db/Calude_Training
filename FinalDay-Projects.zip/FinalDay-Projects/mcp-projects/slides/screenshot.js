const { chromium } = require('/Users/venkatesh/node_modules/playwright');
const path = require('path');

async function run() {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
  for (const n of [1, 2, 3, 4]) {
    await page.goto('file://' + path.join(__dirname, `slide${n}.html`));
    await page.screenshot({ path: path.join(__dirname, `thumbs/slide${n}.png`) });
  }
  await browser.close();
}
run();
