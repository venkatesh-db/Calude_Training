const pptxgen = require('pptxgenjs');
const html2pptx = require('/Users/venkatesh/.claude/skills/pptx/scripts/html2pptx');
const path = require('path');

async function build() {
  const pptx = new pptxgen();
  pptx.layout = 'LAYOUT_16x9';
  pptx.author = 'GhIssuesMcp';
  pptx.title = 'Hooks & Permissions — Project Benefits';

  const dir = __dirname;
  await html2pptx(path.join(dir, 'slide1.html'), pptx);
  await html2pptx(path.join(dir, 'slide2.html'), pptx);
  await html2pptx(path.join(dir, 'slide3.html'), pptx);
  await html2pptx(path.join(dir, 'slide4.html'), pptx);

  const outPath = path.join(dir, '..', 'GhIssuesMcp-Benefits.pptx');
  await pptx.writeFile({ fileName: outPath });
  console.log('wrote', outPath);
}

build().catch(err => { console.error(err); process.exit(1); });
