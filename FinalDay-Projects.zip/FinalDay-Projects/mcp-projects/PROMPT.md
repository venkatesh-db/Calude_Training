# Ticket: MCP — Connecting to the Systems You Actually Run (Hooks & Permissions)

## Context

Our team keeps GitHub Issues as the ticket source of truth. We want an MCP
(Model Context Protocol) server, written in C#/.NET, that lets an MCP client
(Claude, an IDE assistant, etc.) read and act on real GitHub Issues in a
repo — but every mutating action must pass through an explicit
**permission gate**, and every tool call (read or write) must be observable
through **hooks** (pre-call / post-call), so we have an audit trail and a
single choke point to add rate limiting, logging, or approval prompts later.

This is the kind of integration a support/dev-tools team would actually run
in production: connect an AI agent to a real system (GitHub), but don't let
it mutate that system silently.

## Goal

Build a minimal but real MCP server (`GhIssuesMcp`) that exposes GitHub
Issues as MCP tools, with:

1. **Real system connection** — talks to the actual GitHub REST API
   (`api.github.com`) using a personal access token, not a mock.
2. **Tools**
   - `list_issues(owner, repo, state?)` — read-only, lists open/closed issues.
   - `get_issue(owner, repo, number)` — read-only, fetches one issue.
   - `add_comment(owner, repo, number, body)` — **mutating**, posts a comment.
   - `close_issue(owner, repo, number)` — **mutating**, closes an issue.
3. **Permissions** — mutating tools (`add_comment`, `close_issue`) require an
   explicit allow-list check before the HTTP call is made. The allow-list is
   config-driven (appsettings.json: which repos/orgs are writable) — calling
   a mutating tool against a repo not on the allow-list is rejected with a
   clear MCP error, never silently attempted.
4. **Hooks** — every tool call (read or write) goes through a pre-call hook
   (logs the request, checks permissions if mutating) and a post-call hook
   (logs the result/duration, regardless of success or failure). Hooks are
   implemented as a small pipeline every tool invocation passes through, not
   copy-pasted per tool.
5. **Config, not hardcoding** — GitHub token via environment variable
   (`GITHUB_TOKEN`), writable-repo allow-list via `appsettings.json`.

## Non-goals

- No auth/session management beyond a single PAT from the environment.
- No web UI — this is a stdio MCP server for use from an MCP client config.
- No pagination beyond a single page of issues (first 30) — good enough for
  a first ticket.

## Acceptance criteria

- `dotnet build` succeeds.
- Running the server and calling `list_issues` against a real public repo
  (e.g. `octocat/Hello-World`) returns real issue data.
- Calling `add_comment` or `close_issue` against a repo NOT in the allow-list
  returns a permission-denied MCP error and makes no HTTP call.
- Calling `add_comment` or `close_issue` against an allow-listed repo makes
  the real GitHub API call.
- Every tool call produces a pre-call and post-call log line to stderr
  (stdout is reserved for the MCP protocol channel).
