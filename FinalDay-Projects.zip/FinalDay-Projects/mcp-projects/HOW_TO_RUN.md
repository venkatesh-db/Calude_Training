# How to Run GhIssuesMcp

Steps to build, test, and run the MCP server end-to-end. See
[PROMPT.md](PROMPT.md) for what it does and why.

## 1. Install .NET 8 SDK

The MCP C# SDK needs .NET 8+. Check what you have:

```bash
dotnet --list-sdks
```

If .NET 8 isn't listed, install it locally (no admin/sudo needed):

```bash
curl -sSL https://dot.net/v1/dotnet-install.sh -o /tmp/dotnet-install.sh
chmod +x /tmp/dotnet-install.sh
/tmp/dotnet-install.sh --channel 8.0 --install-dir "$HOME/.dotnet8"
```

Then point every command below at it for this session:

```bash
export DOTNET_ROOT="$HOME/.dotnet8"
export PATH="$HOME/.dotnet8:$PATH"
```

## 2. Get a GitHub token

Create one at:
- Fine-grained (recommended): https://github.com/settings/personal-access-tokens/new
- Classic: https://github.com/settings/tokens/new

Minimum permissions needed:
- **Metadata: Read-only** (required by GitHub on all fine-grained tokens)
- **Issues: Read and write** (for `add_comment` / `close_issue`)
- **Administration: Read and write** — only if you also want the token to be
  able to create the sandbox repo you'll write to in step 4; otherwise skip
  this and create the repo yourself in the GitHub UI.

Set it as an environment variable — never commit it or paste it into a file
in this repo:

```bash
export GITHUB_TOKEN=ghp_xxxxxxxxxxxx
```

## 3. Build and test

```bash
cd day4-mcp/GhIssuesMcp
dotnet build

cd ../GhIssuesMcp.Tests
dotnet test
```

Both should finish with 0 errors.

## 4. Pick a repo the server is allowed to write to

Mutating tools (`add_comment`, `close_issue`) only work on repos listed in
`GhIssuesMcp/appsettings.json`. Edit it:

```json
{
  "GitHub": {
    "WritableRepos": ["your-github-username/your-repo"]
  }
}
```

Any repo you have push access to works. If you don't have one handy, create
a small public repo in the GitHub UI (or via API, if your token has
Administration write) and add an issue to it to test against.

## 5. Run the server

```bash
cd day4-mcp/GhIssuesMcp
dotnet run
```

It speaks MCP over stdio and will sit there waiting for a client — that's
expected, it's not a web server.

## 6. Wire it into an MCP client

Add it to your client's MCP config (e.g. Claude Desktop's
`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "gh-issues": {
      "command": "dotnet",
      "args": ["run", "--project", "/absolute/path/to/day4-mcp/GhIssuesMcp"],
      "env": { "GITHUB_TOKEN": "ghp_xxxxxxxxxxxx" }
    }
  }
}
```

Restart the client, then ask it to list issues, get an issue, add a comment,
or close an issue on the repo you allow-listed.

## 7. (Optional) Smoke-test without a client

To confirm the server works before wiring it into a client, speak MCP
JSON-RPC to it directly over stdio: send an `initialize` message, then a
`tools/list`, then a `tools/call` with `{"name": "list_issues", "arguments":
{"owner": "octocat", "repo": "Hello-World"}}` — each as one line of JSON on
stdin, reading one line of JSON back per request.

## What "done" looks like

- `dotnet build` and `dotnet test` both pass.
- `tools/list` returns all 4 tools: `list_issues`, `get_issue`,
  `add_comment`, `close_issue`.
- `list_issues` against any public repo returns real issue data.
- `add_comment` / `close_issue` against a repo **not** in `WritableRepos`
  returns an error and makes no GitHub API call.
- `add_comment` / `close_issue` against an allow-listed repo actually posts
  the comment / closes the issue on GitHub.
