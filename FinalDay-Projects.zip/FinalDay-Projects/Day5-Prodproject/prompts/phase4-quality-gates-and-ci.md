# Phase 4 Prompt — Quality Gates + Headless CI

Use this prompt to (re)generate Phase 4 of the `order-service` reference project. Assumes
Phase 1–3 already exist (skeleton/standards, domain+defects, cross-cutting infra+analytics).

---

**Prompt:**

You are acting as a senior software engineer wiring up the quality-gate tooling and CI
pipeline for `order-service`, so `mvn -q verify` and the GitHub Actions workflow are both
real, runnable gates — not just plugin declarations in `pom.xml` that have never actually
been exercised. Do **not** fix any of the 10 seeded defects in this phase; the gates should
be configured to catch what they're capable of catching, and we'll see in a later phase
which of the 10 defects static analysis actually flags versus which need a human/AI review
pass (that gap is itself instructive).

Context: `pom.xml` already declares Checkstyle, SpotBugs, OWASP dependency-check, and JaCoCo
bound to the `verify` phase, but there is no `checkstyle.xml` config file yet, so `verify`
currently fails on missing config rather than on real findings.

Deliverables for this phase:

1. **`order-service/checkstyle.xml`** — a real, not-maximally-strict ruleset appropriate for
   a Spring Boot service: package/import order, unused imports, line length (120), brace
   placement, javadoc only required on public API classes (not every method), no wildcard
   imports. Should pass cleanly against the Phase 2/3 code as written (the 10 defects are
   logic bugs, not style violations, so they shouldn't trip Checkstyle).

2. **SpotBugs tuning**: add `order-service/spotbugs-exclude.xml` excluding known-noisy,
   not-relevant-here categories (e.g. Lombok-generated code false positives) — but do
   **not** exclude anything that would hide any of the 10 seeded defects (e.g. do not
   exclude SQL injection or unbounded-loop categories).

3. **JaCoCo coverage reality check**: run `mvn -q test` and see what the actual line
   coverage is with the Phase 2/3 tests as they stand. If it's under the 80% gate
   configured in `pom.xml`, either (a) add the missing straightforward unit tests to close
   the gap honestly, or (b) if closing it honestly this phase would mean writing the
   defect-driven regression tests prematurely, lower the gate to the real current number
   with a comment in `pom.xml` explaining it will be raised back to 80% once the defect-sweep
   phase adds its regression tests. Prefer (a) wherever the missing coverage is ordinary
   (untested getters/mappers/controllers), and only fall back to (b) for coverage that
   specifically depends on exercising the 10 defects.

4. **GitHub Actions workflow** (`.github/workflows/ci.yml`):
   - Triggers on push and PR to `main`.
   - Job 1 `build-and-verify`: checkout, set up JDK 21 (Temurin), cache Maven deps, spin up
     Postgres/Redis/Kafka as service containers (or rely on Testcontainers-in-CI with Docker
     already available on the runner — pick whichever is simpler given the test setup from
     Phase 2/3), run `mvn -q verify`, upload the JaCoCo and OWASP dependency-check reports
     as build artifacts.
   - Job 2 `defect-sweep-headless` (depends on Job 1 passing): runs Claude Code
     **non-interactively** (`claude -p "..."` with `--output-format json` or similar) against
     the PR diff, using the defect taxonomy in `CLAUDE.md`, and posts a summary comment on
     the PR listing any of the 10 defect categories it believes are present, with file/line
     references. This job must not have write access to merge or modify code — read-only
     PR-comment permissions only.
   - Fail the workflow (non-zero exit) if Job 1 fails; Job 2's findings should not block
     merge on their own (it's an advisory review, not a hard gate) — reflect that with
     `continue-on-error: true` on Job 2 or an equivalent soft-fail pattern.

5. **Local pre-commit parity**: add a short `scripts/verify.sh` that runs the same
   `mvn -q verify` command CI runs, so a developer (or Claude, via the PostToolUse hook in a
   later phase) gets identical signal locally before pushing.

After writing the config, actually run `mvn -q verify` locally and report the real result
(pass/fail and why) rather than assuming it passes — this phase is specifically about making
the gate trustworthy, so it needs to be exercised, not just declared.

---

## Notes

- The point of "don't fix defects, do check what gates catch" is to produce a genuinely
  useful artifact later: a table of "defect categories caught by static analysis" vs
  "defect categories that needed the AI/human review sweep" — good material for the
  code-flow/thinking diagram and for demonstrating why both automated gates and a
  judgment-based review step are needed in the workflow.
- Keep the headless CI job's prompt to Claude scoped and read-only; it is not authorized to
  push fixes in this phase — that capability (with approval gating) comes later when we wire
  the `/defect-sweep` slash command and sub-agent.
