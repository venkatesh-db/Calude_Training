# Phase 7 Design Note — Order Cancellation + Idempotency Key

## What's changing

`POST /orders/{id}/cancel` — cancels a `PLACED` order, releases its reserved stock, and
publishes an `OrderCancelled` event. `POST /orders` gains an optional `Idempotency-Key`
header so a client retry on a slow request doesn't create a duplicate order.

## Status state machine

`PLACED` is the only cancellable state. `PLACED → CANCELLED` is the only allowed
transition this phase adds. Cancelling an already-`CANCELLED` order is idempotent (200,
returns current state, no-op). Cancelling anything else (e.g. a hypothetical `FULFILLED`
state, not yet modeled) is a 409 conflict. All status transitions go through one guarded
method (`OrderEntity.cancel()`) rather than a raw `setStatus(...)` call anywhere else in
the codebase — the same shape of mistake as the Phase 6 race condition (an invariant
bypassed by a second, less-careful code path) is worth guarding against structurally, not
just by fixing it once.

## Why Redis for the idempotency-key store, not Postgres

The idempotency check has to run before any database write and needs a TTL (a key is only
relevant for as long as a client might retry, not forever). Redis already sits on the hot
path for the stock lock, has native TTL support, and avoids adding a table + cleanup job
for what is inherently ephemeral state. A Postgres table would work too but needs an
explicit expiry job Redis gives for free.

## What was considered and rejected

- **Saga/outbox pattern for the cancel event**: rejected as overkill at this scale. The
  `OrderFulfillmentConsumer`-style pattern (publish after commit, idempotent consumer)
  from Phase 6 is already proven and sufficient — an outbox table adds real operational
  complexity (a relay process, another failure mode) for a benefit (guaranteed
  publish-exactly-once-effectively) the existing idempotent-consumer pattern already gets
  most of the way to.
- **Storing the idempotency key result value (not just a marker) in Redis**, so a retried
  request returns the *exact* original response body: included — a bare "seen it" flag
  isn't enough, since the client's retry still expects a 201 with the order it thinks it
  created, not a bare "already done" error.
