# Phase 5 Prompt — Claude Code Workflow Tooling

Use this prompt to (re)generate Phase 5 of the `order-service` reference project. Assumes
Phase 1–4 already exist (skeleton/standards, domain+defects, cross-cutting infra+analytics,
quality gates + CI). This is the phase that builds the actual senior-engineer *workflow*
tooling around the code, not more application code.

---

**Prompt:**

You are acting as a senior software engineer setting up the Claude Code tooling layer for
`order-service`, so that defect discovery, enhancement work, and review all follow a
repeatable, judgment-aware process instead of ad hoc prompting. Build each of the five
artifacts below. Do not fix any of the 10 seeded defects yet — this phase builds the tools
that will be used to find and fix them in Phase 6.

Deliverables:

1. **Refine `CLAUDE.md`** (already exists from Phase 1) — add two sections if not already
   present:
   - A **"Review checklist"** section that's the human/AI-readable checklist version of the
     defect taxonomy (already there) plus process expectations: every fix needs a RED→GREEN
     test, every enhancement needs a one-paragraph design note, `mvn -q verify` must pass
     before a change is considered done.
   - A **"Workflow tools in this repo"** section listing the slash command, hook, sub-agent,
     and MCP server below, one line each, so a new contributor (human or AI) discovers them
     from `CLAUDE.md` alone.

2. **Custom slash command** — `.claude/commands/defect-sweep.md`. This is a **repeatable
   multi-step workflow with judgement in it**, not a single-shot script. It should instruct
   Claude to:
   - Read `CLAUDE.md`'s defect taxonomy.
   - Run static analysis (`mvn -q verify`) first and note what it already caught.
   - For each of the 10 taxonomy categories, search the diff/codebase for that pattern
     specifically (not just "review the code generally") — this is the judgement part: some
     categories need semantic reasoning (does this read-modify-write actually race?) not
     just grep.
   - For each finding: report file/line, category, a one-sentence explanation of the failure
     scenario, and a proposed fix — but **do not apply the fix without asking**, since this
     command may run against real production code in other contexts, not just this seeded
     repo.
   - If invoked with a `--fix` argument, then after reporting, ask for confirmation once per
     finding (or once for the batch) before writing the regression test + fix for each
     confirmed finding, following the RED→GREEN rule in `CLAUDE.md`.

3. **A hook** — configure `.claude/settings.json` (or point to where the user's global
   settings should add a project-scoped entry) with a **PostToolUse hook** that runs after
   any `Edit`/`Write` to a `*.java` file under `order-service/src/main/`: it should run
   `mvn -q -pl order-service compile` (fast compile-only check, not full verify) and surface
   the result. This is the **"rule that must fire whether or not anyone remembers"** —
   broken code should never sit uncommitted without the developer (or Claude) knowing
   immediately, without relying on anyone remembering to run the build.

4. **A sub-agent** — `.claude/agents/defect-taxonomy-reviewer.md` (or the appropriate
   sub-agent definition location/format for this project). This is the **bounded
   investigation done in isolation**: a sub-agent scoped narrowly to reviewing a diff or
   file set against the 10-category defect taxonomy and returning structured findings
   (file, line, category, severity, one-sentence failure scenario) — without carrying the
   main conversation's full context, and without permission to edit files itself (read-only
   tools: Read, Grep, Glob, Bash for running `mvn verify`/static analysis, nothing else). It
   should be usable both interactively (invoked from the main session) and from the headless
   CI job in Phase 4.

5. **An MCP server** — a small read-only MCP server (or, if writing one from scratch is out
   of scope for this phase, a config entry wiring an existing suitable MCP server, e.g. a
   Postgres introspection MCP) giving Claude **access to a system outside the repo**:
   specifically, the ability to query the running `order-service` Postgres instance
   read-only (e.g. `SELECT * FROM inventory WHERE stock_quantity < 0` to sanity-check the
   race-condition defect's real-world effect, or inspect `processed_events` row counts to
   verify the idempotency defect). Document in `CLAUDE.md`'s "Workflow tools" section how to
   start it (`docker compose up` must already be running) and what it's for. Keep it
   strictly read-only — no write/DDL capability — since this is a debugging aid, not a
   migration tool.

After writing these, do a dry run: invoke the reasoning of `/defect-sweep` manually (without
`--fix`) against the current Phase 2/3 code and report what it finds, so we can sanity-check
the command's instructions actually produce useful output before relying on it in Phase 6.

---

## Notes

- Phase 6 (not yet prompted) will actually run `/defect-sweep --fix` for real and compare
  its findings against `prompts/DEFECTS_ANSWER_KEY.md` — this phase is about building the
  tooling and proving it *would* work, not about fixing anything yet.
- Keep the sub-agent and slash command's tool access minimal and explicit (principle of
  least privilege) since this pattern is meant to generalize to real production repos, not
  just this demo — a defect-review agent with write access to the codebase is a much bigger
  blast radius than one that can only read and report.
