# Phase 7 Prompt — Enhancement Workflow (net-new feature, not a bug fix)

Use this prompt to (re)generate Phase 7 of the `order-service` reference project. Assumes
Phase 1–6 are complete: the 10 seeded defects are fixed (per `DEFECT_SWEEP_RESULTS.md`), and
the full workflow tooling (slash command, hook, sub-agent, MCP server, CI) exists and is
proven out.

This phase is the second half of the original ask — "1. defect fixing, 2. enhancement." It
demonstrates the same senior-engineer, Claude-assisted process applied to **net-new
functionality** instead of bug remediation, so the repo shows both halves of real day-to-day
work, not just cleanup.

---

**Prompt:**

You are acting as a senior software engineer adding a real feature to `order-service`:
**order cancellation with stock release and idempotent client retries.** Use the full
workflow — plan first, TDD, code review, verify — exactly as `CLAUDE.md`'s workflow
expectations require, and exactly as `/defect-sweep`/the sub-agent would review it
afterward.

Feature scope:

1. **`POST /orders/{id}/cancel`** — cancels a `PLACED` order (idempotent: cancelling an
   already-`CANCELLED` order returns 200 with the current state, not an error; cancelling a
   nonexistent order returns 404; cancelling an order in a terminal state other than
   `CANCELLED`, e.g. already `FULFILLED`, returns 409).
2. On cancellation: release each line item's reserved stock back to `inventory` — through
   `InventoryLockService`, correctly this time (Phase 6 already fixed the analogous race
   condition in the fulfillment path; this new code must use that same lock-protected
   pattern from day one, not repeat the original defect).
3. Publish an `OrderCancelled` Kafka event (same envelope pattern as `OrderPlacedEvent`,
   with an `eventId`) so downstream fulfillment/analytics can react; the existing
   `OrderFulfillmentConsumer`-style idempotency pattern (check `processed_events` before
   acting) must be used by whatever consumes it.
4. **Idempotency key support on `POST /orders`** itself, as a client-facing enhancement:
   accept an optional `Idempotency-Key` header; if a request with the same key was already
   processed, return the original response instead of creating a duplicate order. Store
   seen keys (with a TTL) in Redis, not a new Postgres table — this is a good fit for the
   cache layer and keeps the hot path fast.

Process to follow (this is what makes it "the enhancement workflow," not just "write this
code"):

1. **Plan first**: write a short design note (a few paragraphs, can live at the top of the
   PR description or as `prompts/phase7-design-note.md`) covering: the state machine for
   order status (`PLACED → CANCELLED`, `PLACED → FULFILLED`, terminal states reject further
   transitions), why Redis (not Postgres) for the idempotency-key store, and what was
   considered and rejected (e.g. "considered a saga/outbox pattern for the cancel event,
   rejected as overkill at this scale — direct publish-after-commit is sufficient given the
   consumer is already idempotent").
2. **TDD**: for each piece (cancel endpoint state transitions, stock release locking,
   idempotency-key replay), write the test first, watch it fail, implement, watch it pass.
3. **Self-review with the same tooling**: run `/defect-sweep` (no `--fix`, just report)
   against the new code specifically — this is new code, so it should not be exempt from
   the same taxonomy checks that found the original 10 defects. Fix anything it flags before
   calling the feature done.
4. **Verify**: `mvn -q verify` green, including the coverage gate.

Update `CLAUDE.md`'s domain notes if the order status state machine introduced here should
be documented as a standing rule (it should — "status transitions must go through a single
guarded method, never a raw `setStatus` call" is exactly the kind of rule that belongs
there, since it's the same shape of mistake as the original race-condition defect).

---

## Notes

- The point of this phase is contrast: Phase 6 was reactive (find and fix what's already
  broken); Phase 7 is proactive (build new things correctly the first time, using lessons
  already encoded in `CLAUDE.md` and validated by the same review tooling). Together they're
  the full loop the original request asked for.
- If `/defect-sweep` finds nothing in the new code, that's the intended outcome and worth
  stating explicitly in the phase summary — it's evidence the standards in `CLAUDE.md` and
  the TDD discipline actually prevented the same defect classes from recurring, not just
  that the review step happened to miss something.
