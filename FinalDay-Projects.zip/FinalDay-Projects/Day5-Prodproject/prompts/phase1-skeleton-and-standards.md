# Phase 1 Prompt — Skeleton + Repository Standards

Use this prompt to (re)generate Phase 1 of the `order-service` reference project from scratch.

---

**Prompt:**

You are acting as a senior software engineer setting up a new production-grade microservice
repository. Build **Phase 1 only** — skeleton and standards, no business logic yet.

Context:
- Service: an **Order/Inventory** microservice.
- Stack: Java 21, Spring Boot 3.x, PostgreSQL + Spring Data JPA + Flyway, Redis + Redisson
  (distributed locks), Kafka (Redpanda locally) via Spring Kafka, Java Streams/Tablesaw for
  analytics ETL, JUnit 5 + Testcontainers + Awaitility + Gatling for testing, Checkstyle +
  SpotBugs + OWASP dependency-check + JaCoCo (80% line coverage gate) for quality gates,
  Docker Compose + GitHub Actions + OpenTelemetry for ops.
- This repo will later be used to practice AI-assisted defect discovery/fixing and
  enhancement work, so the standards you write now must be strict enough to make defects
  detectable and fixable in a structured way.

Deliverables for this phase:

1. **Maven module skeleton** under `order-service/` with packages split by layer:
   `api`, `domain`, `data`, `cache`, `async`, `events`, `analytics`, `config`, plus
   `src/main/resources/db/migration` for Flyway and a mirrored `src/test/java` tree.
2. **`order-service/pom.xml`** wiring every technology above as a real dependency (not
   placeholders) and binding Checkstyle, SpotBugs, OWASP dependency-check, and JaCoCo to the
   Maven `verify` phase so `mvn -q verify` is the single quality gate command.
3. **`docker-compose.yml`** at the repo root spinning up Postgres, Redis, Redpanda, an
   OpenTelemetry collector, and the service itself, with healthchecks so dependent services
   wait for readiness.
4. **`CLAUDE.md`** at the repo root as the standing repository standard. It must contain:
   - The stack table.
   - Non-negotiable architecture rules (layering boundaries, DTOs never leaking entities,
     BigDecimal for money, mandatory locking pattern for shared inventory state, idempotent
     Kafka consumers, no hardcoded secrets, parameterized SQL only, bounded retries).
   - A numbered **defect taxonomy** (10 categories) that any future review, slash command,
     or sub-agent will check code against — race conditions, N+1 queries, missing Kafka
     idempotency, off-by-one pagination, wrong cache/lock TTL, float money math, missing
     null/Optional handling, unbounded retry loops, SQL injection, secrets in source.
   - Workflow expectations (RED→GREEN regression tests for every fix, design note per
     enhancement, `mvn -q verify` required before calling anything done, no silent
     suppression of static-analysis warnings).
   - A commands section listing how to start infra, run the service, run the quality gate,
     and invoke the defect-sweep workflow.

Do not write any domain/business logic, controllers, entities, or seeded defects in this
phase — that is Phase 2. Confirm the skeleton compiles conceptually (correct package layout,
no missing Maven coordinates) before finishing.

---

## Notes

- This prompt is intentionally scoped to *skeleton + standards only* so the AI doesn't
  jump ahead into business logic before the ground rules exist to judge that logic against.
- Re-running this prompt against a stale repo should be idempotent-ish: it should overwrite
  `pom.xml`, `docker-compose.yml`, and `CLAUDE.md` rather than duplicating them.
