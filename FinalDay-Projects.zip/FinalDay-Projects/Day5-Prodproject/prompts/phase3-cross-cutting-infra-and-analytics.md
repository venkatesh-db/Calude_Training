# Phase 3 Prompt — Cross-Cutting Infra Hardening + Analytics ETL

Use this prompt to (re)generate Phase 3 of the `order-service` reference project. Assumes
Phase 1 (skeleton + `CLAUDE.md`) and Phase 2 (domain/API/data/cache/events, 10 seeded
defects) already exist.

---

**Prompt:**

You are acting as a senior software engineer hardening the cross-cutting infrastructure of
`order-service` and adding its analytics pipeline, on top of the Phase 2 domain code. Do
**not** fix any of the 10 seeded defects in this phase — they stay in place until the
defect-sweep workflow (a later phase) finds and fixes them deliberately. Follow `CLAUDE.md`'s
architecture rules for anything new you write.

Context: Phase 2 already wired the basic Redis/Redisson lock and Kafka producer/consumer.
Phase 3 is about (a) making that infra production-shaped — config, resilience, observability
— and (b) building the `pandas`/`Polars`-equivalent analytics batch job the stack table
calls for, implemented as a Java Streams + Tablesaw ETL job.

Deliverables for this phase:

1. **Redis/cache hardening** (`cache` package):
   - Externalize Redisson connection config (host/port/timeout) into `application.yml`
     properties instead of relying only on Spring Boot's auto-config defaults.
   - Add a `CacheHealthIndicator` (Spring Boot Actuator `HealthIndicator`) that reports
     Redis connectivity so `/actuator/health` reflects real cache state.

2. **Kafka hardening** (`events` package + `config`):
   - Add a `KafkaConfig` class defining explicit producer/consumer factories with sane
     production defaults: `acks=all`, bounded `retries` with backoff (this is where the
     *correct* pattern should live — do not touch `OrderEventProducer`'s existing unbounded
     retry loop, that is defect #8 and stays for now), and consumer `max.poll.records`
     tuning.
   - Add a dead-letter topic (`order-placed.DLT`) wired via a `DefaultErrorHandler` with a
     fixed-backoff `BackOff` policy, so consumer failures don't silently retry forever at
     the Spring Kafka level either.

3. **Async work** (`async` package):
   - A Quartz-scheduled job, `InventoryReconciliationJob`, that runs periodically (e.g. every
     15 minutes) and reconciles `inventory.stock_quantity` against a sum of
     non-cancelled `order_items` for sanity-check/alerting purposes (log a warning on
     mismatch — do not auto-correct silently, that hides bugs rather than surfacing them).

4. **Analytics ETL** (`analytics` package):
   - `OrderAnalyticsEtlJob`: a batch job (triggered by its own Quartz schedule, e.g.
     nightly) that reads orders + order_items for a given date range, loads them into a
     Tablesaw `Table`, and computes: total revenue per day, top-5 SKUs by quantity sold,
     and average order value. Write results to a new `daily_order_metrics` table
     (add the Flyway migration for it).
   - Keep the ETL logic itself framework-free where reasonable (a plain class taking a
     `List<OrderRow>` in, `DailyMetrics` out) with a thin Spring-managed wrapper that
     handles the DB read/write, so the transformation logic is unit-testable without
     Spring context or a real database.

5. **Observability** (`config` package):
   - `ObservabilityConfig` wiring Micrometer + OpenTelemetry: a `Resource` with service
     name/version, OTLP exporter endpoint from config, and a couple of custom
     `Counter`/`Timer` metrics for order placement (count, latency) registered via
     `MeterRegistry`.

6. **Tests**:
   - Unit test for the ETL transformation logic (`OrderAnalyticsEtlJob`'s pure-logic part)
     using a small in-memory `List<OrderRow>` fixture — assert revenue/top-SKU/average
     calculations are correct.
   - Unit test for `InventoryReconciliationJob`'s comparison logic in isolation (mock the
     repositories, assert it logs/flags a mismatch when quantities disagree).

After writing the code, run `mvn -q compile` to confirm it builds, and run the new unit
tests directly (`mvn test -Dtest=OrderAnalyticsEtlJobTest,InventoryReconciliationJobTest`)
to confirm they pass before considering the phase done.

---

## Notes

- This phase deliberately does not touch the 10 seeded defects — mixing "new production
  hardening work" with "fixing planted bugs" would make the later defect-sweep phase
  ungradeable against the answer key.
- The reconciliation job and the ETL job are good candidates for the diagram in a later
  phase (Phase 6): they're the two places async/scheduled work happens outside the request
  path, worth calling out explicitly in the code-flow diagram.
