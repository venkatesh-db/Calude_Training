# Phase 2 Prompt — Core Domain, API, Data, Events + Seeded Defects

Use this prompt to (re)generate Phase 2 of the `order-service` reference project. Assumes
Phase 1 skeleton + `CLAUDE.md` already exist (see `prompts/phase1-skeleton-and-standards.md`).

---

**Prompt:**

You are acting as a senior software engineer implementing the core Order/Inventory business
flow for `order-service`, on top of the Phase 1 skeleton and the standards in `CLAUDE.md`.

Context:
- Flow: client places an order → service reserves stock for each line item → order is
  persisted → an `OrderPlaced` event is published to Kafka → a consumer picks it up for
  downstream fulfillment.
- Follow the layering rules in `CLAUDE.md` strictly: `api` → `domain` → `data`, DTOs never
  leak entities, money is `BigDecimal`, shared inventory state is lock-protected, Kafka
  consumers are idempotent, no hardcoded secrets, parameterized SQL only.

Deliverables for this phase:

1. **Flyway migration** (`V1__init_orders_and_inventory.sql`) creating `orders`,
   `order_items`, and `inventory` tables with appropriate constraints and indexes.
2. **JPA entities** (`data` package): `OrderEntity`, `OrderItemEntity`, `InventoryEntity`.
3. **Repositories** (`data` package): Spring Data JPA repositories for each entity.
4. **Domain layer** (`domain` package): plain Java service interfaces + implementations —
   `OrderService`, `InventoryService` — containing the actual business rules (stock
   reservation, order total calculation, validation). No Spring Web or JPA imports here.
5. **API layer** (`api` package): REST controller (`POST /orders`, `GET /orders/{id}`,
   `GET /orders?page=&size=`) with request/response DTO records and a
   `@ControllerAdvice` error handler.
6. **Cache/locks** (`cache` package): `InventoryLockService` wrapping Redisson for the
   stock-reservation critical section.
7. **Events** (`events` package): `OrderEventProducer` (publishes `OrderPlaced` to Kafka)
   and `OrderFulfillmentConsumer` (consumes it) with an event envelope carrying an event id.
8. **Unit + integration test skeletons** (JUnit 5 + Testcontainers) covering the happy path
   for order placement — these should currently pass; they are not the defect-detection
   tests (those come from `/defect-sweep` later).

**Seed exactly 10 defects into this code**, one from each category in the `CLAUDE.md` defect
taxonomy, each realistic enough to plausibly ship in a real PR (not a deliberately absurd
bug). Distribute them across layers rather than clustering them in one file. Specifically:

1. Race condition — a read-then-write on `inventory.stock_quantity` that bypasses
   `InventoryLockService`.
2. N+1 query — fetching an order's items in a loop instead of a join/fetch.
3. Missing Kafka idempotency — `OrderFulfillmentConsumer` applies side effects without
   checking the event id against a dedupe store.
4. Off-by-one — pagination logic in the `GET /orders` endpoint that skips or duplicates
   a row at page boundaries.
5. Wrong lock TTL — `InventoryLockService`'s Redisson lock TTL set too short relative to
   the critical section it protects, allowing a second thread in.
6. Float money math — order total calculated with `double` instead of `BigDecimal`
   somewhere in `OrderService`.
7. Missing null/Optional handling — a nullable field (e.g. `discountCode`) dereferenced
   without a null check, causing an NPE on a valid input.
8. Unbounded retry — `OrderEventProducer` retries a failed publish in a loop with no
   max attempts or backoff.
9. SQL injection — one raw/native query (e.g. an admin search endpoint) built via string
   concatenation instead of a bound parameter.
10. Secret in source — a hardcoded credential or API key literal somewhere in config or
    a service class instead of being read from environment/Spring config.

Do **not** comment, flag, or mark these defects in the code in any way (no `// BUG:` or
similar) — they must read as ordinary, plausible production code. Keep a separate,
**not-committed-to-the-reviewable-diff** answer key at `prompts/DEFECTS_ANSWER_KEY.md`
(gitignored) listing each defect's file, line, category, and the intended fix, so the defect
sweep in a later phase can be verified against ground truth.

After writing the code, run `mvn -q compile` (not `verify` — the defects should not all be
caught by compilation) to confirm the module builds.

---

## Notes

- The answer key must never appear in code comments or be visible to whatever workflow is
  later asked to *find* the defects — it exists only to grade that workflow's output.
- Keep the happy-path tests green; the defects should be subtle behavioral/security/
  concurrency issues, not things that break basic compilation or the obvious test case.
- Add `prompts/DEFECTS_ANSWER_KEY.md` to `.gitignore` before writing it.
