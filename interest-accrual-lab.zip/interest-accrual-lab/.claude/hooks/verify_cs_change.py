#!/usr/bin/env python3
"""PostToolUse hook: after any .cs edit, build the owning project and run its
matching test project, so build/test failures surface immediately instead of
only when someone remembers to run `dotnet test`.

Scoped to this project's fixed layout (src/<Project> <-> tests/<Project>.Tests).
A net6.0 test project that can't launch at all in a sandbox with no net6.0
runtime installed ("You must install or update .NET to run this application")
is reported as skipped, not as a failure - that's an environment gap, not a
code defect.
"""
import json
import os
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

# src project dir -> matching test project dir (None if it has no test project)
PROJECTS = {
    "src/Banking.Interest": "tests/Banking.Interest.Tests",
    "src/Banking.Ledger": "tests/Banking.Ledger.Tests",
    "src/Banking.Api": "tests/Banking.Api.Tests",
}
TEST_PROJECTS = {
    "tests/Banking.Interest.Tests",
    "tests/Banking.Ledger.Tests",
    "tests/Banking.Api.Tests",
}


def csproj_for(rel_dir: str) -> Path:
    name = os.path.basename(rel_dir.rstrip("/"))
    return PROJECT_ROOT / rel_dir / f"{name}.csproj"


def run_dotnet(args):
    result = subprocess.run(
        ["dotnet", *args],
        cwd=str(PROJECT_ROOT),
        capture_output=True,
        text=True,
    )
    output = (result.stdout or "") + (result.stderr or "")
    return result.returncode, output


def tail(text: str, n: int) -> str:
    return "\n".join(text.strip().splitlines()[-n:])


def emit(summary: str):
    print(json.dumps({
        "systemMessage": summary,
        "hookSpecificOutput": {
            "hookEventName": "PostToolUse",
            "additionalContext": summary,
        },
    }))


def main():
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return

    file_path = (payload.get("tool_input") or {}).get("file_path", "") or ""
    if not file_path.lower().endswith(".cs"):
        return

    normalized = file_path.replace("\\", "/")

    matched = None
    for rel_dir in list(PROJECTS) + list(TEST_PROJECTS):
        if f"/{rel_dir}/" in normalized:
            matched = rel_dir
            break

    if matched is None:
        return

    lines = []
    ok = True
    ran_anything = False

    if matched in TEST_PROJECTS:
        test_dir = matched
    else:
        build_csproj = csproj_for(matched)
        if build_csproj.is_file():
            ran_anything = True
            status, out = run_dotnet(["build", str(build_csproj)])
            if status != 0:
                ok = False
                lines.append(f"BUILD FAILED ({matched}):\n{tail(out, 25)}")
        test_dir = PROJECTS.get(matched)

    if ok and test_dir:
        test_csproj = csproj_for(test_dir)
        if test_csproj.is_file():
            ran_anything = True
            status, out = run_dotnet(["test", str(test_csproj)])
            if "You must install or update .NET" in out:
                lines.append(
                    f"TESTS SKIPPED (no matching .NET runtime installed in this "
                    f"sandbox): {test_dir}"
                )
            elif status != 0:
                ok = False
                lines.append(f"TESTS FAILED ({test_dir}):\n{tail(out, 30)}")
            else:
                lines.append(f"tests passed: {test_dir}")

    if not ran_anything:
        return

    if not lines:
        lines.append(f"build ok: {matched} (no matching test project found)")

    emit("\n\n".join(lines))


if __name__ == "__main__":
    main()
