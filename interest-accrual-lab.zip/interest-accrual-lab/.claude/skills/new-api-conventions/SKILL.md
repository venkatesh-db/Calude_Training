---
name: new-api-conventions
description: End-to-end map of this repo's code flow and conventions (money-path rules, validation style, model shape, xunit patterns) to follow when adding a new API to Banking.Interest or Banking.Ledger, or a new sibling library.
---

# Adding a new API to interest-accrual-lab

This is a reference for extending this codebase, not a general C# style guide. Everything
below is drawn from what `AccrualService` and `PostingService` actually do today, plus the
defect history in `reports/` — follow it so a new API doesn't reintroduce the bug this repo
was built to fix.

## 1. Project shape

- Solution: `InterestAccrualLab.sln`, target framework `net6.0`, `Nullable` and
  `ImplicitUsings` both `enable` in every `.csproj`.
- **Known exception:** `src/Banking.Api` (the HTTP layer, added to wrap
  `PostingService.PostNightlyBatch`) targets `net10.0` instead, because the only
  runtime installed in this dev environment is .NET 10 — the two original class
  libraries' own test projects can't execute here either (confirmed by running
  `dotnet test` and getting "You must install or update .NET to run this
  application"). Don't copy `net10.0` onto a new class library by default; it's
  specific to a web-hosting project that needs `Microsoft.AspNetCore.Mvc.Testing`
  to actually resolve and run integration tests against the installed runtime. If
  you add another web-layer project, match `Banking.Api`, not the class libraries.
  If this repo ever gets the net6.0 runtime installed (or CI does), revisit whether
  `Banking.Api` should move back to `net6.0` for consistency.
- One class library per bounded concern under `src/`, one test project per library under
  `tests/`, named `<Project>.Tests` and referencing only its own project (not the whole
  solution). Namespace matches the folder (`Banking.Interest`, `Banking.Ledger`).
- Today's chain is linear: `Banking.Interest` produces a per-account figure,
  `Banking.Ledger` (which does **not** reference `Banking.Interest`) consumes it via a
  plain data type (`AccountAccrual`) that the caller assembles. A new downstream library
  should follow that same seam — depend on a small data-only model, not on the upstream
  service class — so libraries stay independently testable.

## 2. The model chain (read this before adding a model)

```
Account  --ComputeDailyAccrual-->  decimal  --caller assembles-->  AccountAccrual
                                                                        |
                                                                        v
                                                    PostNightlyBatch(IReadOnlyList<AccountAccrual>)
                                                                        |
                                                                        v
                                                              BatchPostingResult
                                                        { PostedEntries, LedgerBatchTotal,
                                                          SumOfPostedEntries, ReconciliationGap }
```

Every model in this chain is a `sealed class` with `init`-only properties and a
`string.Empty` / default-value fallback (never a nullable reference type for a
required field). `BatchPostingResult.ReconciliationGap` is a computed property
(`LedgerBatchTotal - SumOfPostedEntries`), not a stored field — derive comparison
values instead of duplicating the inputs. Follow this shape for any new model rather
than introducing records or DTOs with a different convention.

## 3. Money-path rules (non-negotiable — this is the actual bug this repo fixes)

- **`decimal` only.** No `double`/`float` anywhere a monetary amount is computed,
  stored, or accumulated — including intermediate variables and loop accumulators.
  This was the entire root cause: a `double` round-trip in `AccrualService` and a
  second `double` accumulator in `PostingService.ComputeLedgerBatchTotal`.
- **Round exactly once per unit of work**, at the point that value is finalized —
  never mid-formula, and never again when it's later summed or re-reported.
  `AccrualService.ComputeDailyAccrual` rounds once, at `return`; everything downstream
  in `PostingService` treats that value as already final and only ever adds it.
- **Rounding call shape:** `Math.Round(value, 2, MidpointRounding.AwayFromZero)`.
  If a new API introduces its own rounding point, use this exact call, not a bespoke
  one — and flag to a human (not a silent engineering call) if a different rounding
  mode looks like it might be needed, since the compliance basis for `AwayFromZero`
  itself is still an open sign-off item (see §6).
- **A batch/aggregate total is always a plain sum of already-rounded entries** — never
  a value with its own independent computation path. If you need a total for a report
  or summary, sum the same collection the per-entry values live in; don't re-derive it.

## 4. Validation conventions

Guard clauses run in this order, at the top of the public method, before any
computation:

1. `if (x is null) throw new ArgumentNullException(nameof(x));` — for a null
   reference-type parameter.
2. `if (x.Field < 0) throw new ArgumentOutOfRangeException(nameof(x), "message");` —
   for an out-of-range value nested inside an otherwise-valid parameter. Note the
   `nameof` still names the *parameter*, not the nested field.
3. Inside a loop over a collection parameter, a per-element data problem (e.g. a
   missing required string) throws `InvalidOperationException`, **not**
   `ArgumentException` — because the problem is discovered while processing, not at
   the method boundary itself. See `PostingService.PostNightlyBatch`'s
   `AccountId` check for the pattern to copy.

## 5. Public API shape

- `sealed class` per service, one clearly-named public method per responsibility
  (`ComputeX`, `PostX`) — not a grab-bag service with many unrelated public methods.
- XML doc `<summary>` on every public method; add a `<remarks>` when the method's
  contract has a non-obvious invariant a caller must know (see `PostingService`'s
  remarks on what the reconciliation job compares) — write it so it stays accurate;
  a stale `<remarks>` describing removed behavior is worse than no remarks (this repo
  currently has exactly that stale-comment issue open — don't add a second one).
  Prefer `IReadOnlyList<T>` for collection inputs and outputs — not `List<T>` or `IEnumerable<T>`.

## 6. What's an engineering decision here vs. a human sign-off

Not everything gets decided in code. Flag rather than silently choose when a change
touches:
- The rounding mode/convention itself (currently `AwayFromZero` — compliance basis
  unconfirmed).
- Interest rates, day-count convention, or accrual schedule.
- Whether historical/already-posted batches need retroactive correction.
- The reconciliation job's own comparison logic.

A new API that touches any of these needs the same "flag, don't decide" treatment
this repo's investigation used — cite file/line, tag the claim CONFIRMED or
HYPOTHESIS, and stop short of implementing the business-policy part yourself.

## 7. Testing conventions

For `Banking.Api` specifically: `WebApplicationFactory<Program>` integration tests
need `Microsoft.AspNetCore.Mvc.Testing` version-aligned with the project's actual
`TargetFramework` (see §1) — a mismatched pin (e.g. the `6.0.x` package running
against the installed .NET 10 runtime) fails with `PipeWriter 'ResponseBodyPipeWriter'
does not implement PipeWriter.UnflushedBytes` on every response that serializes a
JSON body, even though the exact same code works correctly over real Kestrel
(`dotnet run` + `curl`). A green `curl` test is not proof the integration tests
would pass — run `dotnet test` itself before calling anything validated.

For the class libraries (xunit 2.4.1):

- One test class per service class, named `<Service>Tests`, `sealed class`, with a
  private `_sut` field constructed once (`private readonly XService _sut = new();`).
- `[Fact]` for a single fixed case, `[Theory]` + `[InlineData]` for a table of cases.
- **Gotcha:** attribute arguments can't be `decimal` (not a valid C# attribute
  constant type). Pass the literal as `double` in `[InlineData]` even though the test
  method parameter is typed `decimal` — xunit converts it at call time. Don't try to
  write `[InlineData(6661.25m, ...)]`; it won't compile.
- **Gotcha:** if a test computes its own "exact" expected value as an oracle, don't
  compute that oracle with a *different* `MidpointRounding` mode than the production
  code uses and assume it's safe — the two modes only disagree exactly at a `.5` tie.
  `AccrualServiceTests` currently gets away with a `ToEven` oracle only because its two
  known-mismatch cases aren't ties; a genuine midpoint test (still an open item in this
  repo) must compute its expected value with `AwayFromZero` explicitly, matching
  production, or it will assert the wrong number.
- For anything that sums many rounded entries (the reconciliation-sensitive path),
  write a large-N fact — this repo's is 50,000 synthetic accounts — asserting the
  aggregate equals the exact sum, not just checking a couple of hand-picked values.
  Two green unit tests were not sufficient evidence here; the real validation was an
  independent large-N fixture built outside the test suite (see
  `reports/05-validate.md`).

## 8. Checklist for adding a new API

1. Read the existing service in the library you're extending end-to-end first (not
   just its signature) — model your guard clauses, rounding point, and doc comments
   on it directly.
2. Decide what upstream model your new method consumes; if it's a new data type,
   shape it like `AccountAccrual`/`LedgerEntry` (§2), not a new pattern.
3. Write the failing tests first: at minimum, null/invalid-input guard tests and one
   large-N aggregate test if the method sums or batches values.
4. Implement with `decimal` only, one rounding call at the end, guard clauses in the
   order from §4.
5. Run `dotnet test InterestAccrualLab.sln` and confirm the new tests fail before the
   implementation exists, then pass after.
6. If the method touches anything in §6, write down the flag explicitly instead of
   deciding it — don't let it disappear into an implementation detail.
7. Self-review the diff for exactly the three smells already open in this repo (stale
   comments, duplicate summation logic, missing rounding-midpoint coverage) so the new
   API doesn't add a fourth instance of any of them.
