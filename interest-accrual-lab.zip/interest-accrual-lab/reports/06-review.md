# 6. REVIEW — Recon Fail 2026-08-16

Self-review of the diff described in [04-implement.md](04-implement.md).

## What a reviewer would object to

1. **Stale comments left in `PostingService.cs`** (class remarks, lines 15-21, and the `PostNightlyBatch` comment, lines 64-69). They still describe the *old* buggy double round-trip ("round-trips through double before rounding again... for consistency with the summary report formatter downstream") as if it's current behavior. It isn't anymore — the code was fixed but the surrounding prose wasn't, so the file now contradicts itself. Left as-is because the brief was the smallest patch to make the test pass, not a documentation pass, and editing comments in a regulated-money file felt like a decision to flag rather than make unilaterally.

2. **`ComputeLedgerBatchTotal` is now functionally identical to `SumEntries`** — same loop, same accumulation, no rounding. Not collapsed into one method or deleted, per the "smallest patch" instruction; whether to remove the duplicate is a design call noted as open in the original investigation plan, not decided here. A reviewer may reasonably ask why both still exist.

3. **`AccrualServiceTests` still hard-codes `MidpointRounding.ToEven`** in its sanity check (line 69 of that file) even though the service under test now rounds `AwayFromZero`. It passes because neither seeded (principal, rate) pair lands on an exact base-10 midpoint after full-precision decimal division — confirmed by running the suite, not by re-deriving the math by hand. This should not be read as proof the rounding mode is correctly wired end-to-end; a case that actually lands on x.xx5 would be a stronger regression test and none currently exists in the suite.

## What was assumed rather than verified

- That `Math.Round(decimal, 2, MidpointRounding.AwayFromZero)` correctly quantizes to exactly 2 fractional digits across all realistic magnitudes of `PrincipalBalance` × rate in this domain. Extreme values (very large principal, rates with more than 4 decimal places) were not tested.
- That "never round the batch total" means "sum the already-rounded entries with no rounding call at all" (what was implemented), rather than "round it, but only once, at the batch level instead of per-account." Read as the former since it's paired with "round once, per account," but this is an interpretation, not a confirmed spec.
- That the 5,000-account fixture (seed 42, principal up to 500,000, rate up to 0.12) is a fair proxy for the real ~50,000-account book referenced in the original incident. No access to real account data or to `evidence/recon-fail-2026-08-16.txt`, which still does not exist in this working directory.
