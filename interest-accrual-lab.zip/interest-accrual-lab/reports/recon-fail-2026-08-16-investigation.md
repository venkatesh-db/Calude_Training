# Reconciliation Failure Investigation — 2026-08-16 Batch

**Status:** Investigation complete (read-only). No code changed.
**Domain:** Retail banking, daily interest accrual. Rounding/money-representation changes are regulated behaviour changes, not refactors.

## 1. Problem statement

**In scope:** The nightly reconciliation batch fails because the posted ledger batch total does not equal the sum of per-account interest entries. The gap is a few paise across ~50,000 accounts.

**Out of scope for this investigation:** proposing or applying a fix, changing rounding rules, changing accrual math, batch scheduling/retry behavior, or historical/retroactive correction of past batches.

**Evidence caveat:** `evidence/recon-fail-2026-08-16.txt` (the batch diff referenced in the task) does not exist in this working directory. Findings below are based on reading `src/Banking.Interest/AccrualService.cs` and `src/Banking.Ledger/PostingService.cs` directly; the specific numeric diff from the failed batch has not been independently confirmed.

## 2. Trace: per-account interest and batch total

### 2.1 Per-account interest — `AccrualService.ComputeDailyAccrual`
[src/Banking.Interest/AccrualService.cs:18-55](../src/Banking.Interest/AccrualService.cs#L18-L55) — **CONFIRMED**

| Step | Line(s) | Type | Rounding |
|---|---|---|---|
| Read `PrincipalBalance`, `AnnualInterestRate` | model fields | `decimal` | none |
| Cast principal and daily rate down to `double` | 44-45 | `double` | none |
| Multiply `principal * dailyRate` | 47 | `double` | none (binary floating-point) |
| Cast result back to `decimal`, round to 2dp | 52 | `decimal` | `Math.Round(x, 2)`, default `MidpointRounding.ToEven` |

This is the single rounding point for the per-account figure, and it happens **after** a double-precision multiply of values that started as `decimal`.

### 2.2 Batch total, path A — `PostingService.SumEntries`
[src/Banking.Ledger/PostingService.cs:80-90](../src/Banking.Ledger/PostingService.cs#L80-L90) — **CONFIRMED**

- Accumulates already-rounded `entry.Amount` (`decimal`, 2dp) via `total += entry.Amount`.
- Pure `decimal` arithmetic throughout, no cast, no intermediate rounding.
- Produces `SumOfPostedEntries` — the exact sum of what was actually posted per account.

### 2.3 Batch total, path B — `PostingService.ComputeLedgerBatchTotal`
[src/Banking.Ledger/PostingService.cs:96-121](../src/Banking.Ledger/PostingService.cs#L96-L121) — **CONFIRMED**

| Step | Line(s) | Type | Rounding |
|---|---|---|---|
| Declare accumulator | 98 | `double` | none |
| Cast each already-rounded `entry.Amount` to `double` and accumulate | 107 | `double` | none (reintroduces binary floating-point error on values that were already exact) |
| Cast total back to `decimal`, round to 2dp | 120 | `decimal` | second `Math.Round(x, 2)` pass |

Produces `LedgerBatchTotal` — the figure actually posted as the ledger's single batch entry, and the number the nightly recon job compares against `SumOfPostedEntries`.

### 2.4 Root cause of the mismatch — CONFIRMED (from code + inline comments); one sub-claim HYPOTHESIS

`ComputeLedgerBatchTotal` re-derives the batch total by summing the same already-rounded, paise-exact `decimal` entries through a `double` accumulator, then rounds a second time. `SumEntries` sums the identical entries entirely in `decimal`. These two paths are not guaranteed to agree, because `double` cannot exactly represent most 2-decimal-place decimal values — summing ~50,000 of them accumulates representation error that a second rounding pass does not reliably cancel.

The in-code comments (lines 58-70, 92-120) explicitly identify this as the source of the discrepancy and reference `PostingServiceTests` for a worked example. **I have not opened that test file** — treat "the test demonstrates the exact paise-level divergence" as **HYPOTHESIS** until read.

### 2.5 What is *not* the cause

`AccrualService`'s `double`-precision multiply (§2.1) is upstream of and common to *both* `SumEntries` and `ComputeLedgerBatchTotal` — both consume the same already-rounded `entry.Amount` values. It is a separate, latent design concern (mixing `decimal` model fields through `double` math "for legacy COBOL parity") but it cancels out of this specific ledger-vs-sum discrepancy and is not implicated in the recon failure.

## 3. Plan

### Would change
- `ComputeLedgerBatchTotal` ([PostingService.cs:96-121](../src/Banking.Ledger/PostingService.cs#L96-L121)): replace the `double` accumulator with a `decimal` accumulation over the same already-rounded entries, structurally matching `SumEntries`. This makes `LedgerBatchTotal` and `SumOfPostedEntries` identical by construction rather than "usually close."
- Worth deciding (not deciding here): once the two paths are mechanically identical, whether `ComputeLedgerBatchTotal` should be removed entirely and `LedgerBatchTotal` simply set to `SumOfPostedEntries`.

### Would deliberately leave alone
- `AccrualService`'s double-precision multiply before rounding (§2.1, §2.5). Architecturally questionable but not the cause of this failure; per the domain framing, any change to accrual math/rounding is a regulated behavior change requiring its own review, not something to bundle into this fix.
- The `Math.Round(..., 2)` / `MidpointRounding.ToEven` convention itself, wherever it's used — the bank's established rounding rule, not a bug.
- Batch scheduling, retry, and failure-handling behavior — out of scope.

### Not an engineering decision — needs sign-off
- Whether `MidpointRounding.ToEven` is in fact the mandated rounding rule for daily accrual under applicable regulation/product terms. Treated as a given because it's already in place and documented as intentional, but not independently verified against a regulatory or product-policy source.
- Whether the `ComputeLedgerBatchTotal` fix should be classified/approved as "bug fix restoring intended behavior" versus "change to a regulated posting figure" — it changes what gets posted as the ledger's batch total, an external-facing figure, and may need compliance/audit sign-off independent of how clearly it reads as a bug.
- Whether historical batches that posted the incorrect (double-derived) `LedgerBatchTotal` require retroactive correction or disclosure — a business/compliance decision, not an engineering one.

## 4. Open items before implementation

- Locate or obtain `evidence/recon-fail-2026-08-16.txt` and confirm the actual diff magnitude/pattern matches this explanation.
- Read `PostingServiceTests` to confirm the HYPOTHESIS in §2.4 (worked paise-divergence example).
- Get sign-off on the two "not an engineering decision" items in §3 before implementing and shipping the `ComputeLedgerBatchTotal` fix.
