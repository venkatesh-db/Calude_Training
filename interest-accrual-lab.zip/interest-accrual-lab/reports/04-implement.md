# 4. IMPLEMENT — Recon Fail 2026-08-16

**Constraints applied:**
- decimal only. No `double`/`float` anywhere in the money path.
- `MidpointRounding.AwayFromZero`, quantised to 2 decimal places.
- Round once, per account. Never round the batch total.
- No changes to rates, schedule, or the reconciliation job.
- Future accruals only — no historical backfill.

## Failing test, before any patch

Two tests were already seeded in the repo that encode the defects described in the investigation report. Ran the suite unmodified first:

```
dotnet test InterestAccrualLab.sln
```

Result:

```
[xUnit.net 00:00:00.43]     Banking.Interest.Tests.AccrualServiceTests.ComputeDailyAccrual_KnownMismatchPair_MatchesExactDecimalArithmetic(principal: 6661.25, rate: 0.18, expectedExact: 3.29) [FAIL]
[xUnit.net 00:00:00.44]     Banking.Interest.Tests.AccrualServiceTests.ComputeDailyAccrual_KnownMismatchPair_MatchesExactDecimalArithmetic(principal: 1825, rate: 0.187, expectedExact: 0.93) [FAIL]
  Failed Banking.Interest.Tests.AccrualServiceTests.ComputeDailyAccrual_KnownMismatchPair_MatchesExactDecimalArithmetic(principal: 6661.25, rate: 0.18, expectedExact: 3.29) [5 ms]
  Error Message:
   Assert.Equal() Failure
Expected: 3.29
Actual:   3.28
  Failed Banking.Interest.Tests.AccrualServiceTests.ComputeDailyAccrual_KnownMismatchPair_MatchesExactDecimalArithmetic(principal: 1825, rate: 0.187, expectedExact: 0.93) [< 1 ms]
  Error Message:
   Assert.Equal() Failure
Expected: 0.93
Actual:   0.94

Failed!  - Failed:     2, Passed:     3, Skipped:     0, Total:     5, Duration: 3 ms - Banking.Interest.Tests.dll (net6.0)
Passed!  - Failed:     0, Passed:     4, Skipped:     0, Total:     4, Duration: 26 ms - Banking.Ledger.Tests.dll (net6.0)
```

`Banking.Interest.Tests.AccrualServiceTests.ComputeDailyAccrual_KnownMismatchPair_MatchesExactDecimalArithmetic` fails on both seeded (principal, rate) pairs, confirming the `double`-precision defect in `AccrualService.ComputeDailyAccrual`.

`Banking.Ledger.Tests` (including `PostNightlyBatch_LedgerBatchTotal_MatchesSumOfPostedEntries`, which asserts `SumOfPostedEntries == LedgerBatchTotal` and `ReconciliationGap == 0m` over a 50,000-account fixture) passed even before the patch — the double round-trip in `ComputeLedgerBatchTotal` is a real defect per the code comments, but this particular fixture's values didn't happen to trigger a visible divergence. The `double`-based implementation still violates the "decimal only" constraint regardless, so it was fixed anyway.

## Smallest patch

### [src/Banking.Interest/AccrualService.cs](../src/Banking.Interest/AccrualService.cs)

Removed the `double` cast/multiply; single decimal computation; single rounding call with `AwayFromZero`.

```diff
-        // NOTE: principal and rate are both decimal on the Account model,
-        // but the accrual math below is carried out in double for
-        // performance parity with the legacy COBOL accrual job it
-        // replaced. The daily rate and principal are converted down
-        // before the multiplication.
-        double principal = (double)account.PrincipalBalance;
-        double dailyRate = (double)account.AnnualInterestRate / DaysInYear;
-
-        double dailyInterest = principal * dailyRate;
-
-        // Round to 2 decimal places (paise) before returning to the
-        // caller. .NET's default MidpointRounding is ToEven (banker's
-        // rounding), consistent with the rest of the accrual pipeline.
-        decimal rounded = Math.Round((decimal)dailyInterest, 2);
-
-        return rounded;
+        decimal dailyRate = account.AnnualInterestRate / DaysInYear;
+        decimal dailyInterest = account.PrincipalBalance * dailyRate;
+
+        // Single rounding point for the account: 2 decimal places
+        // (paise), MidpointRounding.AwayFromZero. All math above is
+        // decimal-only — no double/float in the money path.
+        return Math.Round(dailyInterest, 2, MidpointRounding.AwayFromZero);
```

### [src/Banking.Ledger/PostingService.cs](../src/Banking.Ledger/PostingService.cs)

`ComputeLedgerBatchTotal` now accumulates in `decimal` (was `double`) and returns the sum unrounded — no second rounding pass on the batch total.

```diff
-    private static decimal ComputeLedgerBatchTotal(IReadOnlyList<LedgerEntry> entries)
-    {
-        double runningTotal = 0d;
-
-        foreach (var entry in entries)
-        {
-            // Each entry.Amount is already a paise-rounded decimal from
-            // AccrualService, but it is summed here as a double before
-            // being rounded again below — reintroducing binary
-            // floating-point representation error on top of a value
-            // that was already exact.
-            runningTotal += (double)entry.Amount;
-        }
-
-        // Second rounding pass: the batch total is rounded again here,
-        // ...
-        return Math.Round((decimal)runningTotal, 2);
-    }
+    private static decimal ComputeLedgerBatchTotal(IReadOnlyList<LedgerEntry> entries)
+    {
+        decimal runningTotal = 0m;
+
+        foreach (var entry in entries)
+        {
+            runningTotal += entry.Amount;
+        }
+
+        return runningTotal;
+    }
```

No changes to rates, batch schedule, the reconciliation job, or any of the model types (`Account`, `AccountAccrual`, `LedgerEntry`, `BatchPostingResult`). No historical/backfill code written.
