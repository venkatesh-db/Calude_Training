# 5. VALIDATE — Recon Fail 2026-08-16

## Full suite, after patch

Command:

```
dotnet test InterestAccrualLab.sln
```

Actual output:

```
  Determining projects to restore...
  All projects are up-to-date for restore.
  Banking.Interest -> .../src/Banking.Interest/bin/Debug/net6.0/Banking.Interest.dll
  Banking.Interest.Tests -> .../tests/Banking.Interest.Tests/bin/Debug/net6.0/Banking.Interest.Tests.dll
Test run for .../tests/Banking.Interest.Tests/bin/Debug/net6.0/Banking.Interest.Tests.dll (.NETCoreApp,Version=v6.0)
  Banking.Ledger -> .../src/Banking.Ledger/bin/Debug/net6.0/Banking.Ledger.dll
Microsoft (R) Test Execution Command Line Tool Version 17.3.0 (arm64)
Copyright (c) Microsoft Corporation.  All rights reserved.

  Banking.Ledger.Tests -> .../tests/Banking.Ledger.Tests/bin/Debug/net6.0/Banking.Ledger.Tests.dll
Starting test execution, please wait...
Test run for .../tests/Banking.Ledger.Tests/bin/Debug/net6.0/Banking.Ledger.Tests.dll (.NETCoreApp,Version=v6.0)
A total of 1 test files matched the specified pattern.
Microsoft (R) Test Execution Command Line Tool Version 17.3.0 (arm64)
Copyright (c) Microsoft Corporation.  All rights reserved.

Starting test execution, please wait...
A total of 1 test files matched the specified pattern.

Passed!  - Failed:     0, Passed:     5, Skipped:     0, Total:     5, Duration: 3 ms - Banking.Interest.Tests.dll (net6.0)

Passed!  - Failed:     0, Passed:     4, Skipped:     0, Total:     4, Duration: 22 ms - Banking.Ledger.Tests.dll (net6.0)
```

**9/9 passed** (5 in `Banking.Interest.Tests`, 4 in `Banking.Ledger.Tests`), including the two previously-failing `ComputeDailyAccrual_KnownMismatchPair_MatchesExactDecimalArithmetic` cases and `PostNightlyBatch_LedgerBatchTotal_MatchesSumOfPostedEntries`.

## 5,000-account fixture

A standalone console fixture was built (outside the repo, `/tmp/fixture-check`, deleted after use) referencing `Banking.Interest` and `Banking.Ledger` directly:

- 5,000 accounts, seeded RNG (`new Random(42)`)
- `PrincipalBalance` up to 500,000, rounded to 2dp
- `AnnualInterestRate` up to 0.12, rounded to 4dp
- Each account run through `AccrualService.ComputeDailyAccrual`, then all 5,000 posted via `PostingService.PostNightlyBatch`

Actual output:

```
Accounts: 5000
SumOfPostedEntries: 203831.35
LedgerBatchTotal:   203831.35
ReconciliationGap:  0.00
```

**`ReconciliationGap` is exactly `0.00`.**
