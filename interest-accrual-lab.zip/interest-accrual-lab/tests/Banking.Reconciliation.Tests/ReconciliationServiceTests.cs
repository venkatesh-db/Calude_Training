using Banking.Ledger;
using Banking.Reconciliation;
using Xunit;

namespace Banking.Reconciliation.Tests;

public sealed class ReconciliationServiceTests
{
    private readonly ReconciliationService _sut = new();

    private static BatchPostingResult MakeResult(decimal ledgerBatchTotal, decimal sumOfPostedEntries)
    {
        return new BatchPostingResult
        {
            PostedEntries = Array.Empty<LedgerEntry>(),
            LedgerBatchTotal = ledgerBatchTotal,
            SumOfPostedEntries = sumOfPostedEntries,
        };
    }

    [Fact]
    public void CheckBatch_ThrowsOnNullResult()
    {
        // Guard clause order per skill §4 item 1: null check must run
        // before any tolerance validation, so even an invalid negative
        // tolerance must not surface before the null check does.
        Assert.Throws<ArgumentNullException>(() => _sut.CheckBatch(null!, 0.01m));
    }

    [Fact]
    public void CheckBatch_ThrowsOnNegativeTolerance()
    {
        var validResult = MakeResult(100.00m, 100.00m);

        Assert.Throws<ArgumentOutOfRangeException>(() => _sut.CheckBatch(validResult, -0.01m));
    }

    [Fact]
    public void CheckBatch_GapWithinTolerance_ReturnsPassedTrue()
    {
        // ReconciliationGap = LedgerBatchTotal - SumOfPostedEntries = 0.01m,
        // exactly equal to tolerance — boundary case: gap == tolerance
        // must pass (<=, not <).
        var result = MakeResult(ledgerBatchTotal: 100.01m, sumOfPostedEntries: 100.00m);

        var report = _sut.CheckBatch(result, 0.01m);

        Assert.True(report.Passed);
        Assert.Equal(0.01m, report.Gap);
        Assert.Equal(0.01m, report.Tolerance);
    }

    [Fact]
    public void CheckBatch_GapExceedsTolerance_ReturnsPassedFalse()
    {
        // Gap = 0.02m, strictly greater than tolerance of 0.01m.
        var result = MakeResult(ledgerBatchTotal: 100.02m, sumOfPostedEntries: 100.00m);

        var report = _sut.CheckBatch(result, 0.01m);

        Assert.False(report.Passed);
    }

    [Fact]
    public void CheckBatch_NegativeGapWithinTolerance_ReturnsPassedTrue()
    {
        // LedgerBatchTotal < SumOfPostedEntries, so ReconciliationGap is
        // negative (-0.01m). The comparison must use Math.Abs(Gap) <=
        // tolerance, not a signed comparison that would wrongly fail a
        // negative-but-small gap.
        var result = MakeResult(ledgerBatchTotal: 99.99m, sumOfPostedEntries: 100.00m);

        var report = _sut.CheckBatch(result, 0.01m);

        Assert.True(report.Passed);
        Assert.Equal(-0.01m, report.Gap);
    }

    [Theory]
    [InlineData(0.0, true)]
    [InlineData(0.01, false)]
    public void CheckBatch_ZeroTolerance_RequiresExactMatch(double gapAsDouble, bool expectedPassed)
    {
        // Gotcha (SKILL.md §7): decimal isn't a valid attribute constant
        // type, so the gap is passed through InlineData as double and
        // converted to decimal here, even though CheckBatch/the model
        // are typed decimal throughout.
        decimal gap = (decimal)gapAsDouble;
        var result = MakeResult(ledgerBatchTotal: 100.00m + gap, sumOfPostedEntries: 100.00m);

        var report = _sut.CheckBatch(result, tolerance: 0.00m);

        Assert.Equal(expectedPassed, report.Passed);
    }

    /// <summary>
    /// Skill §7 large-N requirement: build a batch the same way
    /// PostingServiceTests' 50,000-account fixture does, then assert
    /// CheckBatch's reported Gap is exactly the batch's own
    /// ReconciliationGap, with no re-derivation drift — CheckBatch's
    /// whole job is to react to a batch-summed figure even though it
    /// does not itself sum entries.
    /// </summary>
    [Fact]
    public void CheckBatch_LargeN_ReportReflectsExactGapFromFiftyThousandEntries()
    {
        var accruals = Enumerable.Range(1, 50_000)
            .Select(i => new AccountAccrual
            {
                AccountId = $"ACC-{i}",
                DailyInterest = Math.Round(0.005m * (i % 37), 2),
            })
            .ToList();

        var postingResult = new PostingService().PostNightlyBatch(accruals);

        var report = _sut.CheckBatch(postingResult, tolerance: 0.00m);

        Assert.Equal(postingResult.ReconciliationGap, report.Gap);
    }
}
