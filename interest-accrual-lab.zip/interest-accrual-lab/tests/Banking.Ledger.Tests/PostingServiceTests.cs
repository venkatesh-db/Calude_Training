using Banking.Ledger;
using Xunit;

namespace Banking.Ledger.Tests;

public sealed class PostingServiceTests
{
    private readonly PostingService _sut = new();

    [Fact]
    public void PostNightlyBatch_ThrowsOnNullAccruals()
    {
        Assert.Throws<ArgumentNullException>(() => _sut.PostNightlyBatch(null!));
    }

    [Fact]
    public void PostNightlyBatch_ThrowsWhenAccountIdMissing()
    {
        var accruals = new List<AccountAccrual>
        {
            new() { AccountId = "", DailyInterest = 1.23m },
        };

        Assert.Throws<InvalidOperationException>(() => _sut.PostNightlyBatch(accruals));
    }

    [Fact]
    public void PostNightlyBatch_PostsOneEntryPerAccrual()
    {
        var accruals = new List<AccountAccrual>
        {
            new() { AccountId = "ACC-1", DailyInterest = 1.23m },
            new() { AccountId = "ACC-2", DailyInterest = 4.56m },
        };

        var result = _sut.PostNightlyBatch(accruals);

        Assert.Equal(2, result.PostedEntries.Count);
    }

    /// <summary>
    /// Worked reconciliation example: 50,000 accounts, each posted with
    /// an already-rounded per-account interest amount. The batch total
    /// the ledger posts (<see cref="BatchPostingResult.LedgerBatchTotal"/>)
    /// is expected to equal the sum of those same posted entries
    /// (<see cref="BatchPostingResult.SumOfPostedEntries"/>) exactly, to
    /// the paisa — that equality is what the nightly reconciliation job
    /// checks. The seeded defect in <c>ComputeLedgerBatchTotal</c>
    /// (PostingService.cs:120) re-derives the batch total by summing in
    /// <c>double</c> and rounding again, so across a large batch it
    /// drifts a few paise from the exact decimal sum.
    /// </summary>
    [Fact]
    public void PostNightlyBatch_LedgerBatchTotal_MatchesSumOfPostedEntries()
    {
        var accruals = Enumerable.Range(1, 50_000)
            .Select(i => new AccountAccrual
            {
                AccountId = $"ACC-{i}",
                // Values chosen so a meaningful fraction land on a
                // rounding midpoint, mirroring real balance/rate
                // distributions across a retail deposit book.
                DailyInterest = Math.Round(0.005m * (i % 37), 2),
            })
            .ToList();

        var result = _sut.PostNightlyBatch(accruals);

        Assert.Equal(result.SumOfPostedEntries, result.LedgerBatchTotal);
        Assert.Equal(0m, result.ReconciliationGap);
    }
}
