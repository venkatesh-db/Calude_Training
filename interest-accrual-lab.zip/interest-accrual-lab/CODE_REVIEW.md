# Code Review — Interest Accrual Reconciliation Fix

**Change owner:** venkatesh.db@gmail.com
**Domain:** Retail banking, daily interest accrual
**Type:** Regulated behaviour change (rounding / money representation) — **not** a routine refactor. Needs sign-off beyond normal code review; see "Needs sign-off" section below.

## Summary

The nightly reconciliation batch was failing: the posted ledger batch total did not equal the sum of per-account interest entries, off by a few paise across ~50,000 accounts. Root cause and fix are in two files:

| File | Bug | Fix |
|---|---|---|
| `src/Banking.Interest/AccrualService.cs` | Per-account interest computed via `double`, then cast back to `decimal` and rounded — floating-point representation error before rounding | Compute entirely in `decimal`; round once, `MidpointRounding.AwayFromZero` |
| `src/Banking.Ledger/PostingService.cs` | `ComputeLedgerBatchTotal` re-summed already-rounded entries through a `double` accumulator, then rounded a second time — diverging from the plain-decimal sum used elsewhere in the same file | Sum in `decimal`, no second rounding pass |

Full investigation trail (problem statement → code trace → plan → implementation → validation → self-review) is in [reports/](reports/):
1. [recon-fail-2026-08-16-investigation.md](reports/recon-fail-2026-08-16-investigation.md) — UNDERSTAND / INSPECT / PLAN
2. [04-implement.md](reports/04-implement.md) — the diff, with failing-test-first evidence
3. [05-validate.md](reports/05-validate.md) — test run output + 5,000-account fixture delta
4. [06-review.md](reports/06-review.md) — self-identified review objections
5. [07-report.md](reports/07-report.md) — commands run, files changed, unresolved items

## Constraints this change was built under (agreed before implementation)

- `decimal` only. No `double`/`float` anywhere in the money path.
- `MidpointRounding.AwayFromZero`, quantised to 2 decimal places.
- Round once, per account. Never round the batch total.
- No changes to rates, schedule, or the reconciliation job.
- Historical balances out of scope — future accruals only, no backfill.

## Diff

### `src/Banking.Interest/AccrualService.cs`

```diff
-        // NOTE: principal and rate are both decimal on the Account model,
-        // but the accrual math below is carried out in double for
-        // performance parity with the legacy COBOL accrual job it
-        // replaced. The daily rate and principal are converted down
-        // before the multiplication.
-        double principal = (double)account.PrincipalBalance;
-        double dailyRate = (double)account.AnnualInterestRate / DaysInYear;
-
-        double dailyInterest = principal * dailyRate;
-
-        // Round to 2 decimal places (paise) before returning to the
-        // caller. .NET's default MidpointRounding is ToEven (banker's
-        // rounding), consistent with the rest of the accrual pipeline.
-        decimal rounded = Math.Round((decimal)dailyInterest, 2);
-
-        return rounded;
+        decimal dailyRate = account.AnnualInterestRate / DaysInYear;
+        decimal dailyInterest = account.PrincipalBalance * dailyRate;
+
+        // Single rounding point for the account: 2 decimal places
+        // (paise), MidpointRounding.AwayFromZero. All math above is
+        // decimal-only — no double/float in the money path.
+        return Math.Round(dailyInterest, 2, MidpointRounding.AwayFromZero);
```

**Note:** rounding mode changed from the default `ToEven` to `AwayFromZero` per the agreed constraints. This is a behaviour change to how midpoint paise are rounded for every account, every day — flagged explicitly for reviewer attention.

### `src/Banking.Ledger/PostingService.cs`

```diff
-    private static decimal ComputeLedgerBatchTotal(IReadOnlyList<LedgerEntry> entries)
-    {
-        double runningTotal = 0d;
-
-        foreach (var entry in entries)
-        {
-            runningTotal += (double)entry.Amount;
-        }
-
-        return Math.Round((decimal)runningTotal, 2);
-    }
+    private static decimal ComputeLedgerBatchTotal(IReadOnlyList<LedgerEntry> entries)
+    {
+        decimal runningTotal = 0m;
+
+        foreach (var entry in entries)
+        {
+            runningTotal += entry.Amount;
+        }
+
+        return runningTotal;
+    }
```

(Comments trimmed above for brevity — see [04-implement.md](reports/04-implement.md) for the full diff including comment removal.)

## Test evidence

- **Before patch:** `dotnet test` → 2 failures in `AccrualServiceTests.ComputeDailyAccrual_KnownMismatchPair_MatchesExactDecimalArithmetic` (pre-seeded regression cases). `Banking.Ledger.Tests` passed even before the fix — the double-summation bug in `PostingService` is real per the code comments but wasn't triggered by that particular fixture's values.
- **After patch:** `dotnet test` → **9/9 passed**.
- **5,000-account synthetic fixture** (seeded RNG, randomized principal/rate, run end-to-end through `AccrualService` → `PostingService`): `SumOfPostedEntries = 203831.35`, `LedgerBatchTotal = 203831.35`, **`ReconciliationGap = 0.00`** exactly.

Raw command output for all runs is in [05-validate.md](reports/05-validate.md).

## Known gaps / things I want reviewer eyes on specifically

1. **Stale comments in `PostingService.cs`** (class remarks + `PostNightlyBatch` comment) still describe the old, now-fixed double round-trip as current behaviour. Left untouched deliberately (scoped as "smallest patch"), but they're misleading as-is. Recommend a follow-up doc-only PR.
2. **`ComputeLedgerBatchTotal` and `SumEntries` are now identical in behaviour.** Not consolidated in this change. Worth discussing whether to delete one and have `LedgerBatchTotal` just equal `SumOfPostedEntries` directly.
3. **No test exercises an exact rounding midpoint (x.xx5)** to prove `AwayFromZero` is wired correctly, as opposed to merely not-yet-contradicted by the two seeded fixture values (neither of which lands on a literal midpoint after full-precision decimal division — verified by running the suite, not by hand). Recommend adding one before calling rounding-mode coverage complete.
4. **`evidence/recon-fail-2026-08-16.txt`**, referenced in the original task, does not exist in this working directory. This fix was derived from the source code and its comments (which explicitly document the seeded defects), not from the original batch diff. Would like confirmation this matches the real incident's numbers if/when that evidence surfaces.

## Needs sign-off (not an engineering decision)

- Whether `MidpointRounding.AwayFromZero` is the intended/compliant rounding rule for daily accrual (as opposed to the previous `ToEven`) — implemented per explicit instruction, but that instruction's regulatory basis wasn't independently verified by me.
- Whether this fix changes a regulated, externally-visible posting figure (`LedgerBatchTotal`) in a way that needs compliance/audit review beyond normal code review, given it's a "bug fix" that also changes what actually gets posted going forward.
- Whether historical batches that posted the old (incorrect) `LedgerBatchTotal` need retroactive disclosure or correction — explicitly out of scope for this change (future accruals only), but a business/compliance decision, not one this PR makes.

## Reviewer checklist

- [ ] Confirm `MidpointRounding.AwayFromZero` is the approved rounding rule (see sign-off items above)
- [ ] Confirm no `double`/`float` remains anywhere in the accrual/posting money path
- [ ] Confirm batch total is never rounded a second time
- [ ] Confirm no changes leaked into rates, schedule, or the reconciliation job
- [ ] Decide on follow-ups: stale comments (#1), duplicate summation methods (#2), midpoint regression test (#3)
