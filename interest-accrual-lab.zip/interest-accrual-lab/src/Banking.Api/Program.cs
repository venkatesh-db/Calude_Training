using Banking.Ledger;
using Microsoft.AspNetCore.Mvc;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<PostingService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

// Thin wrapper over PostingService.PostNightlyBatch: accepts already-computed
// per-account accruals and posts them, unchanged. Computing those accruals
// (Banking.Interest.AccrualService) is a separate concern and not this
// endpoint's job.
app.MapPost("/api/postings/nightly-batch", (
    [FromBody] IReadOnlyList<AccountAccrual> accruals,
    PostingService postingService) =>
{
    try
    {
        BatchPostingResult result = postingService.PostNightlyBatch(accruals);
        return Results.Ok(result);
    }
    catch (InvalidOperationException ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
});

app.Run();

public partial class Program
{
}
