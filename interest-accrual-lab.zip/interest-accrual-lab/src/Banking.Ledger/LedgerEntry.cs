namespace Banking.Ledger;

/// <summary>
/// A single interest-accrual entry posted to one account's ledger.
/// </summary>
public sealed class LedgerEntry
{
    public string AccountId { get; init; } = string.Empty;

    public decimal Amount { get; init; }
}
