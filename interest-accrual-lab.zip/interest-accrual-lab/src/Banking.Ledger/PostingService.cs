namespace Banking.Ledger;

/// <summary>
/// Posts the nightly interest accrual batch to the ledger and
/// produces the batch total used by the reconciliation job.
/// </summary>
/// <remarks>
/// The reconciliation job compares two numbers every night:
///   1. <see cref="BatchPostingResult.LedgerBatchTotal"/> — the total
///      this service posts as a single ledger entry.
///   2. The sum of the per-account interest amounts that were posted
///      to each account (<see cref="BatchPostingResult.PostedEntries"/>).
/// These two numbers are expected to match exactly, to the paisa.
///
/// Historically this service posted only the per-account entries and
/// let the reconciliation job sum them for the batch total. A later
/// change added a dedicated batch-total figure so the nightly report
/// could show it without re-summing tens of thousands of entries.
/// That batch-total figure is computed independently below, rather
/// than by summing <see cref="BatchPostingResult.PostedEntries"/>,
/// which is the source of the discrepancy this lab investigates.
/// </remarks>
public sealed class PostingService
{
    /// <summary>
    /// Posts one ledger entry per account and computes the aggregate
    /// batch total posted alongside them.
    /// </summary>
    public BatchPostingResult PostNightlyBatch(IReadOnlyList<AccountAccrual> accruals)
    {
        if (accruals is null)
        {
            throw new ArgumentNullException(nameof(accruals));
        }

        var postedEntries = new List<LedgerEntry>(accruals.Count);

        foreach (var accrual in accruals)
        {
            if (string.IsNullOrWhiteSpace(accrual.AccountId))
            {
                throw new InvalidOperationException(
                    "Accrual is missing an account id and cannot be posted.");
            }

            // Each per-account amount arrives from AccrualService already
            // rounded to 2 decimal places (paise). It is posted to the
            // account's ledger as-is, with no further rounding.
            var entry = new LedgerEntry
            {
                AccountId = accrual.AccountId,
                Amount = accrual.DailyInterest,
            };

            postedEntries.Add(entry);
        }

        // Sum the already-rounded per-account entries. Because every
        // entry is already a 2-decimal-place decimal, a plain decimal
        // sum here would already equal the ledger batch total to the
        // paisa, with no further rounding required.
        decimal exactSumOfEntries = SumEntries(postedEntries);

        // The batch-level posting, however, is produced by a separate
        // "batch summary" code path that predates per-entry rounding
        // being added to AccrualService. It re-derives the total from
        // the same entries but round-trips through double before
        // rounding again, "for consistency with the summary report
        // formatter downstream."
        decimal batchTotal = ComputeLedgerBatchTotal(postedEntries);

        return new BatchPostingResult
        {
            PostedEntries = postedEntries,
            LedgerBatchTotal = batchTotal,
            SumOfPostedEntries = exactSumOfEntries,
        };
    }

    private static decimal SumEntries(IReadOnlyList<LedgerEntry> entries)
    {
        decimal total = 0m;

        foreach (var entry in entries)
        {
            total += entry.Amount;
        }

        return total;
    }

    /// <summary>
    /// Computes the single aggregate figure posted as the batch's
    /// ledger total: a plain decimal sum of the already-rounded
    /// per-account entries, with no further rounding applied.
    /// </summary>
    private static decimal ComputeLedgerBatchTotal(IReadOnlyList<LedgerEntry> entries)
    {
        decimal runningTotal = 0m;

        foreach (var entry in entries)
        {
            runningTotal += entry.Amount;
        }

        return runningTotal;
    }
}
