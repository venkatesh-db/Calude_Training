# Phase 8 Prompt — Load Testing, README, and Unattended CI Proof (.NET)

Use this prompt to (re)generate Phase 8 of the `OrderService` reference project. Assumes
Phase 1–7 are complete: standards, domain code (defects fixed per `DEFECT_SWEEP_RESULTS.md`),
cross-cutting infra + analytics, quality gates + CI, workflow tooling, and the order-cancel
enhancement. This is the closing phase — it doesn't add business logic, it closes out the
two remaining items from the original stack table (NBomber load testing) and produces the
artifacts that let someone else pick up this repo cold.

---

**Prompt:**

You are acting as a senior software engineer closing out `OrderService` for this exercise.
Three deliverables, no new business logic:

1. **NBomber load test** — `OrderService.Tests/LoadTests/OrderPlacementSimulation.cs`:
   - Simulates concurrent `POST /orders` against a running instance, ramping to a level
     that will actually exercise the inventory lock's concurrency path (many virtual users
     targeting the same handful of SKUs, not all-distinct SKUs — otherwise the load test
     never touches the exact contention the lock exists for).
   - Include a lower-volume scenario against `GET /orders` (pagination) and
     `POST /orders/{id}/cancel` (the Phase 7 feature) so all three hot paths get coverage.
   - Set explicit pass/fail assertions via NBomber's `Assertion` API (e.g. p95 latency
     under some threshold, 0% failed requests at the target load) so this is a real gate,
     not just a report generator.
   - Do not wire this into `scripts/verify.sh` from Phase 4 — load tests are slow and
     belong in a separate, manually or nightly triggered entry point (e.g.
     `dotnet run --project OrderService.Tests -- --loadtest`, gated behind an explicit flag
     rather than running as part of `dotnet test`).

2. **Root `README.md`** — the narrative entry point for anyone (human or AI) opening this
   repo for the first time. Should cover, concisely:
   - What this repo is and why it exists (a reference implementation of an AI-assisted
     senior-engineer workflow: defect discovery/fixing + enhancement, not just a toy
     microservice).
   - The stack table (from `CLAUDE.md`).
   - How to run it locally (`docker compose up`, `dotnet run --project OrderService.Api`,
     smoke-test curl commands for place/get/list/cancel order).
   - A short table of the 8 phases with one line each and a link to each phase's prompt
     under `prompts/`, so the build history is traceable and reproducible.
   - A link to `DEFECT_SWEEP_RESULTS.md` and a one-paragraph pull-out of the single most
     interesting finding (almost certainly the race condition or lock-TTL defect — the ones
     static analysis structurally cannot catch) as the "why this whole exercise mattered"
     payoff.
   - The workflow tools table (slash command / hook / sub-agent / MCP server / headless CI)
     with one line each on what problem each one solves, mirroring your original request's
     framing so the mapping is explicit.

3. **Unattended headless CI proof** — actually trigger the Phase 4 GitHub Actions workflow
   end-to-end with no further interaction (a real push or a `gh workflow run`), let both jobs
   (`build-and-verify` and `defect-sweep-headless`) complete on their own, and capture the
   result: link/reference to the run, whether it passed, and what the headless defect-sweep
   job posted as its advisory comment. Report this back plainly — pass or fail — rather than
   assuming success; if `gh` isn't authenticated or there's no remote configured, say so
   explicitly and describe what a successful run would look like instead of fabricating one.

---

## Notes

- This phase should not silently claim things it hasn't verified — the same discipline
  applied throughout (RED before GREEN, `scripts/verify.sh` actually run and reported)
  applies here: if the unattended CI run can't actually be triggered in this environment
  (no GitHub remote, no `gh` auth), say that plainly rather than writing a README section
  describing a run that never happened.
- After this phase, the repo is meant to stand on its own: someone should be able to read
  `README.md` top to bottom and understand what was built, why, and how to reproduce any
  part of it from the `prompts/` directory.
- NBomber is the idiomatic .NET-native choice here rather than trying to run Gatling (JVM)
  against a .NET target — it integrates with `dotnet test`/`dotnet run` the same way the
  rest of this stack does, which matters for the "someone can pick this up cold" goal.
