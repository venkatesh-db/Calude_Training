# Phase 2 Prompt — Core Domain, API, Data, Events + Seeded Defects (.NET)

Use this prompt to (re)generate Phase 2 of the `OrderService` reference project. Assumes
Phase 1 skeleton + `CLAUDE.md` already exist (see `prompts/phase1-skeleton-and-standards-dotnet.md`).

---

**Prompt:**

You are acting as a senior software engineer implementing the core Order/Inventory business
flow for `OrderService`, on top of the Phase 1 skeleton and the standards in `CLAUDE.md`.

Context:
- Flow: client places an order → service reserves stock for each line item → order is
  persisted → an `OrderPlaced` event is published to Kafka → a consumer picks it up for
  downstream fulfillment.
- Follow the layering rules in `CLAUDE.md` strictly: `Api` → `Domain` → `Data`, DTOs never
  leak entities, money is `decimal`, shared inventory state is lock-protected, Kafka
  consumers are idempotent, no hardcoded secrets, parameterized SQL only.

Deliverables for this phase:

1. **EF Core migration** (`Migrations/..._InitOrdersAndInventory.cs`, generated via
   `dotnet ef migrations add`) creating `orders`, `order_items`, and `inventory` tables
   with appropriate constraints and indexes.
2. **EF Core entities** (`OrderService.Data` project): `OrderEntity`, `OrderItemEntity`,
   `InventoryEntity`.
3. **Repositories** (`OrderService.Data` project): repository classes wrapping
   `OrderDbContext` for each entity (EF Core doesn't need a generated-repository
   abstraction the way Spring Data does, so write these as thin, explicit classes rather
   than reaching for a generic repository-of-everything pattern).
4. **Domain layer** (`OrderService.Domain` project): plain C# service interfaces +
   implementations — `IOrderService`/`OrderService`, `IInventoryService`/`InventoryService` —
   containing the actual business rules (stock reservation, order total calculation,
   validation). No ASP.NET Core or EF Core imports here.
5. **API layer** (`OrderService.Api` project): REST controller (`POST /orders`,
   `GET /orders/{id}`, `GET /orders?page=&size=`) with request/response DTOs as C#
   `record` types and global exception-handling middleware (`IExceptionHandler`,
   registered via `AddExceptionHandler`).
6. **Cache/locks** (`OrderService.Cache` project): `InventoryLockService` wrapping
   RedLock.net for the stock-reservation critical section.
7. **Events** (`OrderService.Events` project): `OrderEventProducer` (publishes
   `OrderPlaced` to Kafka via Confluent.Kafka's `IProducer<string, string>`) and
   `OrderFulfillmentConsumer` (consumes it via `IConsumer<string, string>`) with an event
   envelope carrying an event id.
8. **Unit + integration test skeletons** (xUnit + Testcontainers for .NET) covering the
   happy path for order placement — these should currently pass; they are not the
   defect-detection tests (those come from `/defect-sweep` later).

**Seed exactly 10 defects into this code**, one from each category in the `CLAUDE.md` defect
taxonomy, each realistic enough to plausibly ship in a real PR (not a deliberately absurd
bug). Distribute them across layers rather than clustering them in one file. Specifically:

1. Race condition — a read-then-write on `inventory.stock_quantity` that bypasses
   `InventoryLockService`.
2. N+1 query — fetching an order's items in a loop instead of `.Include()`/a join.
3. Missing Kafka idempotency — `OrderFulfillmentConsumer` applies side effects without
   checking the event id against a dedupe store.
4. Off-by-one — pagination logic in the `GET /orders` endpoint that skips or duplicates
   a row at page boundaries.
5. Wrong lock TTL — `InventoryLockService`'s RedLock.net expiry set too short relative to
   the critical section it protects, allowing a second thread/request in.
6. Float money math — order total calculated with `double` instead of `decimal`
   somewhere in `OrderService`.
7. Missing null handling — a nullable field (e.g. `DiscountCode`) dereferenced without a
   null check (with nullable reference types enabled from Phase 1, this defect must be
   introduced via a `!` null-forgiving operator or a suppressed warning — make that the
   actual bug, since it defeats the compiler protection deliberately, the same way the
   defect would slip past a linter in the Java version).
8. Unbounded retry — `OrderEventProducer` retries a failed publish in a loop with no
   max attempts or backoff.
9. SQL injection — one raw/native query (e.g. an admin search endpoint) built via string
   interpolation instead of a parameterized `FromSqlInterpolated`/bound parameter.
10. Secret in source — a hardcoded credential or API key literal somewhere in
    `appsettings.json` defaults or a service class instead of being read from environment/
    `IConfiguration`/user-secrets.

Do **not** comment, flag, or mark these defects in the code in any way (no `// BUG:` or
similar) — they must read as ordinary, plausible production code. Keep a separate,
**not-committed-to-the-reviewable-diff** answer key at `prompts/DEFECTS_ANSWER_KEY.md`
(gitignored) listing each defect's file, line, category, and the intended fix, so the defect
sweep in a later phase can be verified against ground truth.

After writing the code, run `dotnet build` (not the full test+coverage gate — the defects
should not all be caught by compilation) to confirm the solution builds.

---

## Notes

- The answer key must never appear in code comments or be visible to whatever workflow is
  later asked to *find* the defects — it exists only to grade that workflow's output.
- Keep the happy-path tests green; the defects should be subtle behavioral/security/
  concurrency issues, not things that break basic compilation or the obvious test case.
- Add `prompts/DEFECTS_ANSWER_KEY.md` to `.gitignore` before writing it.
- Defect #7 is worth being deliberate about: nullable reference types make "forgot a null
  check" harder to seed accidentally in .NET than in Java, since the compiler warns by
  default. The seeded defect must actively suppress or bypass that warning — which is
  itself realistic, since that's exactly how this bug class survives in real .NET codebases.
