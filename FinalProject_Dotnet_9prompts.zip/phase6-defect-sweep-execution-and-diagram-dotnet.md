# Phase 6 Prompt — Run the Defect Sweep for Real + Architecture/Flow Diagram (.NET)

Use this prompt to (re)generate Phase 6 of the `OrderService` reference project. Assumes
Phase 1–5 already exist (skeleton/standards, domain+defects, cross-cutting infra+analytics,
quality gates+CI, and the `/defect-sweep` command/hook/sub-agent/MCP server).

This is the phase where the seeded defects actually get found and fixed, and where the
whole exercise pays off as a demonstrable artifact — the architecture/flow diagram and the
scorecard of what automation caught versus what needed judgement.

---

**Prompt:**

You are acting as a senior software engineer running the defect-remediation and
verification pass on `OrderService`, using the tooling built in Phase 5. Do this in two
parts.

### Part A — Run the real defect sweep

1. Invoke `/defect-sweep` (no `--fix`) against the full `OrderService` codebase as it
   stands from Phase 2/3. Let it run `scripts/verify.sh` first and report what static
   analysis (analyzers/OWASP dependency-check) already caught on its own, then let it work
   through the 10 taxonomy categories.
2. Compare the command's findings against `prompts/DEFECTS_ANSWER_KEY.md` (do this
   comparison yourself as the outer process — the sweep itself must not read the answer key,
   that would defeat the exercise). Record, per defect:
   - Found by static analysis alone?
   - Found by the taxonomy-driven review (the sub-agent/slash-command reasoning)?
   - Missed entirely on this pass?
3. For every defect the sweep found (ideally all 10, but report honestly if some were
   missed and needed a second, more targeted pass), re-run `/defect-sweep --fix`, confirming
   each fix as the workflow prompts, and for each one:
   - Write the regression test first, run it, confirm it fails (RED).
   - Apply the fix.
   - Run the regression test again, confirm it passes (GREEN).
   - Run `scripts/verify.sh` to confirm nothing else broke.
4. Produce `DEFECT_SWEEP_RESULTS.md` at the repo root (this one **is** committable, unlike
   the answer key) summarizing, per defect: category, one-line description, whether it was
   caught by tooling vs. judgement, the regression test added, and the commit-worthy fix
   description. This is the scorecard artifact — it's the evidence that the workflow works,
   suitable for showing a reviewer or using as onboarding material.

### Part B — Architecture / code-flow / thinking diagram

Now that the defects are fixed and the codebase reflects real, current behavior, produce a
diagram (as a Claude Artifact, SVG or HTML) covering:

1. **Request-time flow**: `POST /orders` → `OrderController` → `OrderService.PlaceOrder` →
   `InventoryLockService` (Redis lock via RedLock.net) → `InventoryService.ReserveStockForOrder`
   → Postgres write → `OrderEventProducer` → Kafka (`order-placed` topic). Show where the
   fixed idempotency/locking/retry logic now sits.
2. **Async/event flow**: Kafka `order-placed` → `OrderFulfillmentConsumer` (now
   idempotency-checked against `processed_events`) → `InventoryService.AdjustStockForFulfillment`
   (now lock-protected).
3. **Scheduled/background flow**: Quartz.NET → `InventoryReconciliationJob` and
   `OrderAnalyticsEtlJob`, both reading from Postgres, the reconciliation job alerting on
   mismatch, the ETL job writing `daily_order_metrics`.
4. **The AI-assisted workflow loop itself**, as a separate small diagram or a clearly
   distinct section of the same artifact: PR opened → CI `build-and-verify` job →
   headless `defect-sweep-headless` CI job (advisory) → human/AI review using
   `/defect-sweep` and the `defect-taxonomy-reviewer` sub-agent interactively → confirmed
   fixes with RED→GREEN tests → `scripts/verify.sh` green → merge. Annotate which of your
   five requested tool types (slash command, hook, sub-agent, MCP server, CI/headless) sits
   at which point in this loop.

Publish the diagram as an Artifact and share the link/summary; don't just describe it in
prose.

---

## Notes

- Part A's honesty matters more than a perfect score — if the taxonomy-driven review misses
  something static analysis also misses (e.g. the race condition or the wrong lock TTL,
  which are semantic/concurrency issues no analyzer catches), that's the most valuable
  finding in this whole exercise: it's the empirical case for why a judgement-based review
  step is necessary alongside automated gates, which is the thing you originally asked how
  to demonstrate.
- Keep `DEFECT_SWEEP_RESULTS.md` and the diagram in sync with each other and with the actual
  code — regenerate both together if either the code or the sweep results change later.
