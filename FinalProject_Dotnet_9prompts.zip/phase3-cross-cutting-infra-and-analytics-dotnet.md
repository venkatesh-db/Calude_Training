# Phase 3 Prompt — Cross-Cutting Infra Hardening + Analytics ETL (.NET)

Use this prompt to (re)generate Phase 3 of the `OrderService` reference project. Assumes
Phase 1 (skeleton + `CLAUDE.md`) and Phase 2 (domain/API/data/cache/events, 10 seeded
defects) already exist.

---

**Prompt:**

You are acting as a senior software engineer hardening the cross-cutting infrastructure of
`OrderService` and adding its analytics pipeline, on top of the Phase 2 domain code. Do
**not** fix any of the 10 seeded defects in this phase — they stay in place until the
defect-sweep workflow (a later phase) finds and fixes them deliberately. Follow `CLAUDE.md`'s
architecture rules for anything new you write.

Context: Phase 2 already wired the basic Redis/RedLock.net lock and Kafka producer/consumer.
Phase 3 is about (a) making that infra production-shaped — config, resilience, observability
— and (b) building the `pandas`/`Polars`-equivalent analytics batch job the stack table
calls for, implemented as a LINQ + `Microsoft.Data.Analysis` (`DataFrame`) ETL job.

Deliverables for this phase:

1. **Redis/cache hardening** (`OrderService.Cache` project):
   - Externalize RedLock.net/`StackExchange.Redis` connection config (host/port/timeout)
     into `appsettings.json` via a strongly-typed `RedisOptions` bound with
     `IOptions<RedisOptions>`, instead of relying only on hardcoded defaults.
   - Add a `CacheHealthCheck` (`IHealthCheck`, registered via `AddHealthChecks()`) that
     reports Redis connectivity so `/health` reflects real cache state.

2. **Kafka hardening** (`OrderService.Events` project + `OrderService.Config`):
   - Add a `KafkaConfig` class defining explicit producer/consumer configuration with sane
     production defaults: `Acks = Acks.All`, bounded retry with backoff (this is where the
     *correct* pattern should live — do not touch `OrderEventProducer`'s existing unbounded
     retry loop, that is defect #8 and stays for now), and consumer `max.poll.records`
     (`ConsumeResult` batch tuning) settings.
   - Add a dead-letter topic (`order-placed.dlt`) wired via a manual retry-then-produce-
     to-DLT pattern in the consumer's error path (Confluent.Kafka has no built-in
     `DefaultErrorHandler` equivalent to Spring Kafka's, so implement this explicitly with
     a bounded retry count and a fixed-backoff delay before publishing to the DLT), so
     consumer failures don't silently retry forever.

3. **Async work** (`OrderService.Async` project):
   - A Quartz.NET-scheduled job, `InventoryReconciliationJob`, that runs periodically (e.g.
     every 15 minutes) and reconciles `inventory.stock_quantity` against a sum of
     non-cancelled `order_items` for sanity-check/alerting purposes (log a warning on
     mismatch — do not auto-correct silently, that hides bugs rather than surfacing them).

4. **Analytics ETL** (`OrderService.Analytics` project):
   - `OrderAnalyticsEtlJob`: a batch job (triggered by its own Quartz.NET schedule, e.g.
     nightly) that reads orders + order_items for a given date range, loads them into a
     `Microsoft.Data.Analysis.DataFrame`, and computes: total revenue per day, top-5 SKUs
     by quantity sold, and average order value. Write results to a new
     `daily_order_metrics` table (add the EF Core migration for it).
   - Keep the ETL logic itself framework-free where reasonable (a plain class taking an
     `IEnumerable<OrderRow>` in, `DailyMetrics` out) with a thin DI-managed wrapper that
     handles the DB read/write, so the transformation logic is unit-testable without a
     DI container or a real database.

5. **Observability** (`OrderService.Config` project):
   - `ObservabilityConfig` wiring the OpenTelemetry .NET SDK: a `ResourceBuilder` with
     service name/version, OTLP exporter endpoint from config, and a couple of custom
     `Counter<T>`/`Histogram<T>` metrics for order placement (count, latency) registered
     via `System.Diagnostics.Metrics.Meter`.

6. **Tests**:
   - Unit test for the ETL transformation logic (`OrderAnalyticsEtlJob`'s pure-logic part)
     using a small in-memory `List<OrderRow>` fixture — assert revenue/top-SKU/average
     calculations are correct.
   - Unit test for `InventoryReconciliationJob`'s comparison logic in isolation (mock the
     repositories, assert it logs/flags a mismatch when quantities disagree).

After writing the code, run `dotnet build` to confirm it builds, and run the new unit tests
directly (`dotnet test --filter "FullyQualifiedName~OrderAnalyticsEtlJobTest|FullyQualifiedName~InventoryReconciliationJobTest"`)
to confirm they pass before considering the phase done.

---

## Notes

- This phase deliberately does not touch the 10 seeded defects — mixing "new production
  hardening work" with "fixing planted bugs" would make the later defect-sweep phase
  ungradeable against the answer key.
- The reconciliation job and the ETL job are good candidates for the diagram in a later
  phase (Phase 6): they're the two places async/scheduled work happens outside the request
  path, worth calling out explicitly in the code-flow diagram.
- Confluent.Kafka genuinely lacks a direct equivalent to Spring Kafka's declarative
  `DefaultErrorHandler` + `BackOff` — this is called out explicitly above rather than
  hand-waved, since it's the one place the .NET side needs more manual wiring than Java.
