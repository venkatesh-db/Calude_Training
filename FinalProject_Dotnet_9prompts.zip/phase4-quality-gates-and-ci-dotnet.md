# Phase 4 Prompt — Quality Gates + Headless CI (.NET)

Use this prompt to (re)generate Phase 4 of the `OrderService` reference project. Assumes
Phase 1–3 already exist (skeleton/standards, domain+defects, cross-cutting infra+analytics).

---

**Prompt:**

You are acting as a senior software engineer wiring up the quality-gate tooling and CI
pipeline for `OrderService`, so `scripts/verify.sh` and the GitHub Actions workflow are both
real, runnable gates — not just package references in the `.csproj` files that have never
actually been exercised. Do **not** fix any of the 10 seeded defects in this phase; the
gates should be configured to catch what they're capable of catching, and we'll see in a
later phase which of the 10 defects static analysis actually flags versus which need a
human/AI review pass (that gap is itself instructive).

Context: The `.csproj` files already reference analyzers, OWASP dependency-check, and
Coverlet, but there is no `.editorconfig`/analyzer ruleset file yet, so a full build
currently produces default, unfiltered analyzer noise rather than a curated, real gate.

Deliverables for this phase:

1. **`OrderService/.editorconfig`** — a real, not-maximally-strict ruleset appropriate for
   an ASP.NET Core service: `using` order, unused usings, line length (120 via
   `max_line_length`), brace placement, XML-doc only required on public API classes (not
   every method), no wildcard/blanket suppressions. Should pass cleanly against the
   Phase 2/3 code as written (the 10 defects are logic bugs, not style violations, so they
   shouldn't trip the analyzer/style gate).

2. **Analyzer tuning**: add a `GlobalSuppressions.cs` or `.editorconfig` severity overrides
   excluding known-noisy, not-relevant-here diagnostic IDs (e.g. source-generator false
   positives) — but do **not** suppress anything that would hide any of the 10 seeded
   defects (e.g. do not suppress SQL-injection-pattern or unbounded-loop-adjacent
   diagnostics).

3. **Coverlet coverage reality check**: run `dotnet test --collect:"XPlat Code Coverage"`
   and see what the actual line coverage is with the Phase 2/3 tests as they stand. If it's
   under the 80% gate configured in Phase 1, either (a) add the missing straightforward
   unit tests to close the gap honestly, or (b) if closing it honestly this phase would mean
   writing the defect-driven regression tests prematurely, lower the gate to the real
   current number with a comment in the coverage threshold config explaining it will be
   raised back to 80% once the defect-sweep phase adds its regression tests. Prefer (a)
   wherever the missing coverage is ordinary (untested mappers/controllers), and only fall
   back to (b) for coverage that specifically depends on exercising the 10 defects.

4. **GitHub Actions workflow** (`.github/workflows/ci.yml`):
   - Triggers on push and PR to `main`.
   - Job 1 `build-and-verify`: checkout, set up .NET 8 SDK, cache NuGet packages, spin up
     Postgres/Redis/Kafka as service containers (or rely on Testcontainers-in-CI with Docker
     already available on the runner — pick whichever is simpler given the test setup from
     Phase 2/3), run `scripts/verify.sh`, upload the Coverlet and OWASP dependency-check
     reports as build artifacts.
   - Job 2 `defect-sweep-headless` (depends on Job 1 passing): runs Claude Code
     **non-interactively** (`claude -p "..."` with `--output-format json` or similar) against
     the PR diff, using the defect taxonomy in `CLAUDE.md`, and posts a summary comment on
     the PR listing any of the 10 defect categories it believes are present, with file/line
     references. This job must not have write access to merge or modify code — read-only
     PR-comment permissions only.
   - Fail the workflow (non-zero exit) if Job 1 fails; Job 2's findings should not block
     merge on their own (it's an advisory review, not a hard gate) — reflect that with
     `continue-on-error: true` on Job 2 or an equivalent soft-fail pattern.

5. **Local pre-commit parity**: add a short `scripts/verify.sh` that runs
   `dotnet build -warnaserror && dotnet test --collect:"XPlat Code Coverage"` — the same
   commands CI runs — so a developer (or Claude, via the PostToolUse hook in a later phase)
   gets identical signal locally before pushing.

After writing the config, actually run `scripts/verify.sh` locally and report the real
result (pass/fail and why) rather than assuming it passes — this phase is specifically about
making the gate trustworthy, so it needs to be exercised, not just declared.

---

## Notes

- The point of "don't fix defects, do check what gates catch" is to produce a genuinely
  useful artifact later: a table of "defect categories caught by static analysis" vs
  "defect categories that needed the AI/human review sweep" — good material for the
  code-flow/thinking diagram and for demonstrating why both automated gates and a
  judgment-based review step are needed in the workflow.
- Keep the headless CI job's prompt to Claude scoped and read-only; it is not authorized to
  push fixes in this phase — that capability (with approval gating) comes later when we wire
  the `/defect-sweep` slash command and sub-agent.
- .NET's built-in nullable-reference-types + analyzer warnings-as-errors already catch a
  slightly different slice of bugs than Checkstyle/SpotBugs do — worth stating explicitly
  in the Phase 6 scorecard rather than assuming the two stacks' static analysis coverage
  maps one-to-one.
