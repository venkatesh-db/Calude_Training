# Phase 1 Prompt — Skeleton + Repository Standards (.NET)

Use this prompt to (re)generate Phase 1 of the `OrderService` reference project from scratch.

---

**Prompt:**

You are acting as a senior software engineer setting up a new production-grade microservice
repository. Build **Phase 1 only** — skeleton and standards, no business logic yet.

Context:
- Service: an **Order/Inventory** microservice.
- Stack: .NET 8, ASP.NET Core Web API, PostgreSQL + EF Core + EF Core Migrations, Redis +
  RedLock.net (distributed locks), Kafka (Redpanda locally) via Confluent.Kafka,
  LINQ + Microsoft.Data.Analysis (`DataFrame`) for analytics ETL, xUnit + Testcontainers
  for .NET + a Polly-based polling helper (the Awaitility equivalent) + NBomber for load
  testing, dotnet format + .NET analyzers (Roslyn/`AnalysisMode=All`) + OWASP
  dependency-check (.NET target) + Coverlet (80% line coverage gate) for quality gates,
  Docker Compose + GitHub Actions + OpenTelemetry .NET SDK for ops.
- This repo will later be used to practice AI-assisted defect discovery/fixing and
  enhancement work, so the standards you write now must be strict enough to make defects
  detectable and fixable in a structured way.

Deliverables for this phase:

1. **.NET solution skeleton** under `OrderService/` with projects split by layer:
   `OrderService.Api`, `OrderService.Domain`, `OrderService.Data`, `OrderService.Cache`,
   `OrderService.Async`, `OrderService.Events`, `OrderService.Analytics`,
   `OrderService.Config` (or a shared config/options project), plus
   `OrderService.Data/Migrations` for EF Core and a mirrored `OrderService.Tests` project
   tree. Wire all projects into `OrderService.sln`.
2. **`OrderService.Api/OrderService.Api.csproj`** (and sibling `.csproj` files) wiring
   every technology above as a real NuGet package reference (not placeholders), and a
   `Directory.Build.props` at the solution root enabling nullable reference types,
   `TreatWarningsAsErrors`, and binding dotnet-format check, analyzers, OWASP
   dependency-check, and Coverlet so `dotnet build && dotnet test --collect:"XPlat Code
   Coverage"` (wrapped in one script) is the single quality gate command.
3. **`docker-compose.yml`** at the repo root spinning up Postgres, Redis, Redpanda, an
   OpenTelemetry collector, and the service itself, with healthchecks so dependent services
   wait for readiness.
4. **`CLAUDE.md`** at the repo root as the standing repository standard. It must contain:
   - The stack table.
   - Non-negotiable architecture rules (layering boundaries, DTOs never leaking entities,
     `decimal` for money, mandatory locking pattern for shared inventory state, idempotent
     Kafka consumers, no hardcoded secrets, parameterized SQL only, bounded retries).
   - A numbered **defect taxonomy** (10 categories) that any future review, slash command,
     or sub-agent will check code against — race conditions, N+1 queries, missing Kafka
     idempotency, off-by-one pagination, wrong cache/lock TTL, float money math, missing
     null handling, unbounded retry loops, SQL injection, secrets in source.
   - Workflow expectations (RED→GREEN regression tests for every fix, design note per
     enhancement, `scripts/verify.sh` required before calling anything done, no silent
     suppression of analyzer warnings).
   - A commands section listing how to start infra, run the service, run the quality gate,
     and invoke the defect-sweep workflow.

Do not write any domain/business logic, controllers, entities, or seeded defects in this
phase — that is Phase 2. Confirm the skeleton compiles conceptually (correct project layout,
no missing NuGet package references) before finishing.

---

## Notes

- This prompt is intentionally scoped to *skeleton + standards only* so the AI doesn't
  jump ahead into business logic before the ground rules exist to judge that logic against.
- Re-running this prompt against a stale repo should be idempotent-ish: it should overwrite
  the `.csproj` files, `docker-compose.yml`, and `CLAUDE.md` rather than duplicating them.
- `decimal` in C# is the direct native equivalent of Java's `BigDecimal` for money —
  no external library is needed, unlike the Java side.
