# Phase 9 Prompt — Split the Skill from the Slash Command (correcting a mapping error) (.NET)

Use this prompt to (re)generate Phase 9 of the `OrderService` reference project. Assumes
Phase 1–8 exist (or their prompts exist, pending execution). This phase corrects a mistake
from earlier planning: the "custom slash command" and "a Skill" were originally collapsed
into a single artifact (`/defect-sweep`). They are two distinct mechanisms in Claude Code
and the original request listed them as two separate rows — this phase builds both, properly
separated, with a clear division of responsibility between them.

---

**Prompt:**

You are acting as a senior software engineer correcting the Claude Code tooling layer for
`OrderService` so it has both a **slash command** and a **Skill**, matching these two
distinct roles:

- **Slash command** = "something you type most days" — a short, low-ceremony trigger for a
  routine action. Fast to invoke, thin, mostly delegates.
- **Skill** = "a repeatable multi-step workflow with judgement in it" — the actual packaged
  reasoning: instructions, checklists, decision points, examples, possibly reference files —
  reusable across sessions and invokable by name, not just from one command.

Deliverables:

1. **`.claude/skills/defect-taxonomy-review/SKILL.md`** (or the correct Skill directory
   convention for this project's Claude Code setup) — this is the actual multi-step,
   judgement-bearing workflow, moved out of the slash command file. It should contain:
   - A description clear enough that Claude picks it up correctly when relevant (per the
     Skill-authoring convention: name, one-line description used for triggering, then the
     full instructions).
   - The full defect-sweep reasoning previously drafted in Phase 5's `/defect-sweep`
     description: read `CLAUDE.md`'s taxonomy, run `scripts/verify.sh` first and note what
     static analysis already caught, then for each of the 10 categories reason
     specifically about whether it's present (not a generic "review the code" pass),
     produce structured findings (file, line, category, failure scenario, proposed fix),
     and never apply a fix without asking first.
   - A second mode within the same Skill for the `--fix` flow: after findings are reported
     and confirmed, write the regression test (RED), apply the fix, confirm the test passes
     (GREEN), run `scripts/verify.sh`.
   - Keep this Skill applicable beyond just this repo's 10 seeded defects — it should read
     as a generally reusable "defect taxonomy review" skill that happens to consume
     `CLAUDE.md`'s taxonomy as its input, not a one-off script hardcoded to this project.

2. **`.claude/commands/defect-sweep.md`** — rewritten to be genuinely thin: a short command
   that takes an optional `--fix` argument and invokes the Skill above, passing through the
   flag. This is the thing a developer types most days (`/defect-sweep` or
   `/defect-sweep --fix`) without needing to remember or re-explain the full workflow each
   time — that reasoning now lives in the Skill, not duplicated in the command.

3. **Update `CLAUDE.md`'s "Workflow tools in this repo" section** (added in Phase 5) to
   list the Skill and the slash command as two separate lines with their distinct roles
   spelled out, matching the distinction above — so this mapping error doesn't get repeated
   by a future contributor reading `CLAUDE.md` cold.

4. **Update the sub-agent** (`defect-taxonomy-reviewer` from Phase 5) if needed so it also
   references/reuses the Skill's instructions rather than duplicating the taxonomy-review
   logic a third time — three places (slash command, Skill, sub-agent) independently
   re-describing "how to check for the 10 defect categories" is exactly the kind of
   duplication `CLAUDE.md`'s own standards (DRY, no redundant abstractions) would flag.
   The sub-agent's distinguishing role is running this review **in isolation** (bounded
   context, headless-callable) — not having different instructions for what to check.

After writing these, do a short dry-run description of the corrected flow: what happens when
a developer types `/defect-sweep`, versus what happens when Claude decides on its own to
invoke the Skill (e.g. during a general code review) without the slash command being typed
at all — this contrast is the actual point of having both.

---

## Notes

- This phase is a correction, not new scope — it fixes the earlier conflation rather than
  adding a ninth independent feature. Once done, all eight rows from the original request's
  table have a distinct, correctly-mapped artifact:
  prompt → CLAUDE.md → slash command → Skill → hook → MCP server → sub-agent → headless CI.
- If Phase 5 has already been executed by the time this phase runs, this phase edits the
  existing `.claude/commands/defect-sweep.md` in place (moving its body out into the new
  Skill file) rather than leaving both a fat command and a duplicate Skill.
- This correction is identical in spirit and mechanics on both stacks — the Skill/slash-
  command distinction is a Claude Code concept, not a language concept, so nothing here
  changes between the Java and .NET versions of this repo beyond the file paths and the
  commands the Skill/command shell out to.
